import http from 'node:http';
import { readFileSync, existsSync, mkdirSync } from 'node:fs';
import { stat, readFile } from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { createTseSync } from './tse-sync.mjs';
import { comparePayloads } from './bu-compare.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(__dirname, 'public');
const RUNTIME = process.env.DATA_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH || path.join(__dirname, 'runtime');
mkdirSync(RUNTIME, { recursive: true });
const PORT = Number(process.env.PORT || 8787);
const isProd = process.env.NODE_ENV === 'production';

const locations = JSON.parse(readFileSync(path.join(PUBLIC, 'data', 'locais-colmeia.json'), 'utf8'));
const sectionToPlace = new Map();
for (const place of locations.locais) for (const sec of place.secoes) sectionToPlace.set(Number(sec), place.id);
const allowedCargos = new Set(['presidente','governador','senador','depFederal','depEstadual']);

const db = new DatabaseSync(path.join(RUNTIME, 'central.sqlite'));
db.exec(`
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS results (
  section INTEGER NOT NULL,
  cargo TEXT NOT NULL,
  place_id TEXT NOT NULL,
  local_payload_json TEXT,
  official_payload_json TEXT,
  public_payload_json TEXT NOT NULL,
  verification_status TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY(section, cargo)
);
CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  action TEXT NOT NULL,
  section INTEGER,
  cargo TEXT,
  place_id TEXT,
  actor TEXT NOT NULL,
  before_json TEXT,
  after_json TEXT,
  created_at TEXT NOT NULL
);
`);

const getRow = db.prepare('SELECT * FROM results WHERE section=? AND cargo=?');
const listRows = db.prepare('SELECT * FROM results ORDER BY section, cargo');
const insertRow = db.prepare(`INSERT INTO results(section,cargo,place_id,local_payload_json,official_payload_json,public_payload_json,verification_status,updated_at,updated_by,version)
VALUES(?,?,?,?,?,?,?,?,?,1)`);
const updateRow = db.prepare(`UPDATE results SET place_id=?,local_payload_json=?,official_payload_json=?,public_payload_json=?,verification_status=?,updated_at=?,updated_by=?,version=version+1 WHERE section=? AND cargo=?`);
const deleteRow = db.prepare('DELETE FROM results WHERE section=? AND cargo=?');
const insertAudit = db.prepare('INSERT INTO audit(action,section,cargo,place_id,actor,before_json,after_json,created_at) VALUES(?,?,?,?,?,?,?,?)');
const auditRows = db.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT ?');

function safeJson(v, fallback={}) { try { return JSON.parse(v); } catch { return fallback; } }
function cleanPayload(input, actor, sourceKind) {
  const candidatos = Array.isArray(input.candidatos) ? input.candidatos.map(c => ({
    nome: String(c.nome || '').slice(0,120),
    numero: String(c.numero || '').slice(0,12),
    partido: String(c.partido || '').slice(0,30),
    votos: Math.max(0, Number(c.votos || 0) | 0)
  })) : [];
  const legendas = Array.isArray(input.legendas) ? input.legendas.map(l => ({
    numero: String(l.numero || '').slice(0,4),
    votos: Math.max(0, Number(l.votos || 0) | 0)
  })) : [];
  const rawBu = input.buMeta && typeof input.buMeta === 'object' ? input.buMeta : null;
  const buMeta = rawBu ? {
    zona: Math.max(0, Number(rawBu.zona || 0) | 0),
    secao: Math.max(0, Number(rawBu.secao || 0) | 0),
    secaoOriginal: Math.max(0, Number(rawBu.secaoOriginal || 0) | 0),
    municipioCodigo: String(rawBu.municipioCodigo || '').slice(0,12),
    urnaId: String(rawBu.urnaId || '').slice(0,30),
    pleito: String(rawBu.pleito || '').slice(0,20),
    turno: Math.max(0, Number(rawBu.turno || 0) | 0),
    versaoQr: String(rawBu.versaoQr || '').slice(0,20),
    hash: String(rawBu.hash || '').replace(/[^A-Fa-f0-9]/g,'').slice(0,128),
    assinaturaPresente: !!rawBu.assinaturaPresente,
    qrParts: Math.max(0, Number(rawBu.qrParts || 0) | 0),
    qrTotal: Math.max(0, Number(rawBu.qrTotal || 0) | 0),
    fingerprint: String(rawBu.fingerprint || '').replace(/[^A-Fa-f0-9]/g,'').slice(0,64),
    parsedAt: String(rawBu.parsedAt || '').slice(0,40),
    votosNominais: Math.max(0, Number(rawBu.votosNominais || 0) | 0),
    votosLegenda: Math.max(0, Number(rawBu.votosLegenda || 0) | 0)
  } : null;
  const rawOfficial = input.officialMeta && typeof input.officialMeta === 'object' ? input.officialMeta : null;
  const officialMeta = rawOfficial ? {
    fileName:String(rawOfficial.fileName||'').slice(0,240), batchHash:String(rawOfficial.batchHash||'').slice(0,256),
    sha256:String(rawOfficial.sha256||'').replace(/[^A-Fa-f0-9]/g,'').slice(0,64), decoderVersion:String(rawOfficial.decoderVersion||'').slice(0,80), format:String(rawOfficial.format||'').slice(0,60)
  } : null;
  return {
    candidatos,
    legendas,
    buMeta,
    officialMeta,
    brancos: Math.max(0, Number(input.brancos || 0) | 0),
    nulos: Math.max(0, Number(input.nulos || 0) | 0),
    comparecimento: Math.max(0, Number(input.comparecimento || 0) | 0),
    fonte: String(input.fonte || (sourceKind === 'tse' ? 'TSE' : 'Boletim de Urna')).slice(0,100),
    atualizadoEm: new Date().toISOString(),
    enviadoPor: actor,
    sourceKind
  };
}
function comparisonOf(a,b) {
  const left = typeof a === 'string' ? safeJson(a) : a;
  const right = typeof b === 'string' ? safeJson(b) : b;
  return comparePayloads(left,right);
}
function rowToPayload(row) {
  const p = safeJson(row.public_payload_json);
  p.verificationStatus = row.verification_status;
  p.version = row.version;
  p.placeId = row.place_id;
  p.updatedBy = row.updated_by;
  return p;
}
function snapshot() {
  const results = {};
  let latest = null;
  for (const row of listRows.all()) {
    results[`${row.section}:${row.cargo}`] = rowToPayload(row);
    if (!latest || row.updated_at > latest) latest = row.updated_at;
  }
  return {results, updatedAt: latest, total: Object.keys(results).length};
}

function adminOverview() {
  const cargos = [...allowedCargos];
  const rows = listRows.all();
  const status = tseSync.getStatus();
  const bySection = new Map();
  for (const [sec, placeId] of sectionToPlace.entries()) {
    const place = locations.locais.find(x => x.id === placeId);
    bySection.set(Number(sec), {
      section:Number(sec), placeId, placeName:place?.nome || placeId, region:place?.regiao || '',
      localCargos:[], officialCargos:[], publicCargos:[], verification:{verified:0,divergent:0,local_pending:0,tse_official:0,other:0},
      lastUpdate:null, lastActor:null
    });
  }
  for (const row of rows) {
    const item = bySection.get(Number(row.section)); if (!item) continue;
    if (row.local_payload_json) item.localCargos.push(row.cargo);
    if (row.official_payload_json) item.officialCargos.push(row.cargo);
    if (row.public_payload_json) item.publicCargos.push(row.cargo);
    const k = Object.prototype.hasOwnProperty.call(item.verification,row.verification_status) ? row.verification_status : 'other';
    item.verification[k]++;
    if (!item.lastUpdate || row.updated_at > item.lastUpdate) { item.lastUpdate=row.updated_at; item.lastActor=row.updated_by; }
  }
  let totalLocalCargos=0, totalVerified=0, totalDivergent=0, sectionsLocalComplete=0, sectionsWithAnyLocal=0, tseBuDownloaded=0, tseEa18=0;
  const sections = [...bySection.values()].sort((a,b)=>a.section-b.section).map(item=>{
    item.localCargos.sort((a,b)=>cargos.indexOf(a)-cargos.indexOf(b));
    item.officialCargos.sort((a,b)=>cargos.indexOf(a)-cargos.indexOf(b));
    item.localCargoCount=item.localCargos.length;
    item.localComplete=item.localCargoCount===cargos.length;
    item.missingLocalCargos=cargos.filter(c=>!item.localCargos.includes(c));
    const tse = status?.sections?.[String(item.section)] || {};
    item.tse={ea18Received:!!(tse.hashCount>0 || tse.received),officialBuListed:!!tse.officialBuListed,officialBuDownloaded:!!tse.officialBuDownloaded,officialImageBuDownloaded:!!tse.officialImageBuDownloaded,officialVotaDownloaded:!!tse.officialVotaDownloaded,structuredOfficialReady:!!tse.structuredOfficialReady,decoderStatus:tse.decoderStatus||null,signatureDownloaded:!!tse.signatureDownloaded,batchStatus:tse.batchStatus||null};
    item.alert = item.verification.divergent>0 ? 'divergence' : item.verification.verified===cargos.length ? 'verified' : item.localComplete ? (item.tse.structuredOfficialReady?'compare_processing':item.tse.officialBuDownloaded?'decoder_wait':'local_complete') : item.localCargoCount>0 ? 'partial_local' : 'missing_local';
    totalLocalCargos+=item.localCargoCount; totalVerified+=item.verification.verified; totalDivergent+=item.verification.divergent;
    if(item.localCargoCount>0) sectionsWithAnyLocal++; if(item.localComplete) sectionsLocalComplete++; if(item.tse.officialBuDownloaded)tseBuDownloaded++; if(item.tse.ea18Received)tseEa18++;
    return item;
  });
  return {
    generatedAt:new Date().toISOString(), cargosExpected:cargos.length, sectionsExpected:sections.length,
    summary:{sectionsWithAnyLocal,sectionsLocalComplete,totalLocalCargos,totalExpectedLocalCargos:sections.length*cargos.length,totalVerified,totalDivergent,sectionsVerified:sections.filter(x=>x.verification.verified===cargos.length).length,sectionsDivergent:sections.filter(x=>x.verification.divergent>0).length,tseEa18,tseBuDownloaded,structuredOfficialReady:sections.filter(x=>x.tse.structuredOfficialReady).length,alerts:sections.filter(x=>x.alert==='divergence'||x.alert==='partial_local').length},
    tse:{phase:status?.phase||'unknown',message:status?.message||'',summary:status?.summary||{}}, sections
  };
}

const BUILTIN_TOKEN_HASHES = new Map(Object.entries({"74908e03d0b2e26542a09483727b2655a911784aae51377f8af9c02e8533e6f6":{"name":"Coordenação","role":"admin","sections":["*"],"places":["*"]},"8cc4ad759718f00c138a9363a5c94763adcfd185a6d70a27d611fc7c440c8c9f":{"name":"Operador · Seção 1 · Colégio Estadual Serra das Cordilheiras","role":"operator","sections":[1],"places":["serra-cordilheiras"]},"378963744965990f0f6ea7369983dc29d9157ea06bd74d3606ef658cbc9edc44":{"name":"Operador · Seção 2 · Colégio Estadual Serra das Cordilheiras","role":"operator","sections":[2],"places":["serra-cordilheiras"]},"d14a0d4bdbfa5e90cb7cb40941c043de1eec405cfaaa1f8a1a7f07350a301075":{"name":"Operador · Seção 3 · Colégio Estadual Serra das Cordilheiras","role":"operator","sections":[3],"places":["serra-cordilheiras"]},"bae72055432c650e131de33804f1e2a59791260b1209643a2714eddee1d9bf5d":{"name":"Operador · Seção 4 · Colégio Estadual Serra das Cordilheiras","role":"operator","sections":[4],"places":["serra-cordilheiras"]},"1d4e003a82be9bc9ff1f69ee97942b53a3bc452bc946e262fe0c5db1c6206ecc":{"name":"Operador · Seção 5 · CMEI Euripades Vieira de Sousa","role":"operator","sections":[5],"places":["cmei-euripades"]},"9af804c2329b828786130e2e4358ed9c0448a3d3481ca356686dbf1e92d2ea62":{"name":"Operador · Seção 6 · CMEI Euripades Vieira de Sousa","role":"operator","sections":[6],"places":["cmei-euripades"]},"5abc064328413c8cbd002b2de69c4e267c0337b5afba8729b99c92639663c403":{"name":"Operador · Seção 7 · CMEI Euripades Vieira de Sousa","role":"operator","sections":[7],"places":["cmei-euripades"]},"c665c96e102d244ae864301cd8219d2e360aab2a4eed844e7c949da6a5038920":{"name":"Operador · Seção 8 · CMEI Fabiano Ribeiro de Oliveira","role":"operator","sections":[8],"places":["cmei-fabiano"]},"77d877413d728483124a0f3731da33eb2da52cfff41e1bc7a03b57b9e9e32a65":{"name":"Operador · Seção 9 · CMEI Fabiano Ribeiro de Oliveira","role":"operator","sections":[9],"places":["cmei-fabiano"]},"c25a006e4fa596ffe65ae2480981689cf821c752217078aadf3472d7286461a9":{"name":"Operador · Seção 10 · APAE - Associação de Pais e Amigos dos Excepcionais","role":"operator","sections":[10],"places":["apae"]},"0a98badeacc16f89bfb0c45df377d99e88d5311b6006a47a554b539e784bfa37":{"name":"Operador · Seção 11 · APAE - Associação de Pais e Amigos dos Excepcionais","role":"operator","sections":[11],"places":["apae"]},"2fd06da96c903467713c16ec43e3fa23e96d8dce23ca51b19d07e9b49da10d9c":{"name":"Operador · Seção 12 · Colégio Estadual Serra das Cordilheiras","role":"operator","sections":[12],"places":["serra-cordilheiras"]},"eb7406fda34940493915397a9fed4d759638f7d5912cd1be87480c144b9e592b":{"name":"Operador · Seção 13 · Escola Municipal Marechal Humberto Castelo Branco","role":"operator","sections":[13],"places":["marechal"]},"f5c35bc9fcc7f2836edcbc7675b8d633b056cae123f312f2a3201ba3df89b29e":{"name":"Operador · Seção 14 · Colégio Estadual Ary Ribeiro Valadão Filho CMTO XXII","role":"operator","sections":[14],"places":["ary-ribeiro"]},"ed7040638ba915cc04c0f6546296feb8adb243141ed33c59f30cdce505ca7af5":{"name":"Operador · Seção 15 · Colégio Estadual Ary Ribeiro Valadão Filho CMTO XXII","role":"operator","sections":[15],"places":["ary-ribeiro"]},"70e95370123563ea96c0257599b6876cb50722405082defed435a7eba31b4a60":{"name":"Operador · Seção 16 · Colégio Estadual Ary Ribeiro Valadão Filho CMTO XXII","role":"operator","sections":[16],"places":["ary-ribeiro"]},"b8fd5fa5600961fb4a70bb6b900782f565106ab3d56257bf0981eb9ef960ea48":{"name":"Operador · Seção 41 · Escola Estadual Juscelino Kubitschek de Oliveira","role":"operator","sections":[41],"places":["goiany"]},"779c175e4f379d207bb5c3d76c15f0bae662213d81a0e3334bf21583dd902333":{"name":"Operador · Seção 46 · Escola Municipal Marechal Humberto Castelo Branco","role":"operator","sections":[46],"places":["marechal"]},"515d69b403c0cf189f7c06b44fb0f62de0a7426c2981816d57603c6e8bf4d080":{"name":"Operador · Seção 49 (Agregada: 113) · Centro Educacional Arte do Saber","role":"operator","sections":[49],"places":["arte-saber"]},"0862e12c8f03f46bb911322b684ec3dab01680b043b620e28a02c41ec570ec69":{"name":"Operador · Seção 52 · Escola Municipal Josefina Ribeiro dos Santos","role":"operator","sections":[52],"places":["josefina"]},"cd84f495b998044c406173b53476bb1f2d2e5987c7391d01d9c08c8d3a8926ef":{"name":"Operador · Seção 53 · Escola Estadual Juscelino Kubitschek de Oliveira","role":"operator","sections":[53],"places":["goiany"]},"c66c2796b099ac26efe83975584280524543bd193e00da1ace25611b3f7aa284":{"name":"Operador · Seção 81 · Escola Municipal Josefina Ribeiro dos Santos","role":"operator","sections":[81],"places":["josefina"]},"14a1dbaf3ac357b3440ee2e70d1f9788fe09a48cab163ad20a47da4f15d6b6dc":{"name":"Operador · Seção 83 · APAE - Associação de Pais e Amigos dos Excepcionais","role":"operator","sections":[83],"places":["apae"]},"8a3f7ffcc5a2c0bd6a0e046fef3a824b1dd13e092564b07e74bb921756180c3d":{"name":"Operador · Seção 85 · Escola Municipal Carlos Chagas","role":"operator","sections":[85],"places":["matinha"]},"c5fd21499019a8e6952d13f6c236ca54f16d12294dff7fbfc3992b9ab1648b1d":{"name":"Operador · Seção 89 · CMEI Euripades Vieira de Sousa","role":"operator","sections":[89],"places":["cmei-euripades"]},"edaca070d773c780f7ad493523191d0b60e7ce8f38574f871f53f6997e21a0ab":{"name":"Operador · Seção 92 · Colégio Estadual Ary Ribeiro Valadão Filho CMTO XXII","role":"operator","sections":[92],"places":["ary-ribeiro"]},"05d62ef492a00017ba25a77e3cab88941f31d2257855d186db2d0e280d39b329":{"name":"Operador · Seção 99 · CMEI Fabiano Ribeiro de Oliveira","role":"operator","sections":[99],"places":["cmei-fabiano"]},"7eec03243d1da010b510a3e000f34c88451af5996365a9c73d4049461f6a463d":{"name":"Operador · Seção 100 · APAE - Associação de Pais e Amigos dos Excepcionais","role":"operator","sections":[100],"places":["apae"]},"4aed51fccdee2f646495db6d9265e06003f44100ba5fa887b01f5193e52cf217":{"name":"Operador · Seção 101 · Escola Municipal Josefina Ribeiro dos Santos","role":"operator","sections":[101],"places":["josefina"]}}));

function parseLegacyOperatorsForDev() {
  const map = new Map();
  if (isProd) return map;
  const adminToken = process.env.ADMIN_TOKEN || 'COLMEIA-ADMIN-DEMO';
  if (adminToken) map.set(adminToken, {name:'Coordenação', role:'admin', sections:['*'], places:['*']});
  if (process.env.OPERATOR_TOKENS) {
    const raw = safeJson(process.env.OPERATOR_TOKENS, {});
    for (const [token, info] of Object.entries(raw)) if (token) {
      const sections = Array.isArray(info?.sections)
        ? info.sections.map(Number).filter(Number.isInteger)
        : [];
      const places = Array.isArray(info?.places) ? info.places.map(String) : [];
      map.set(token, {
        name: String(info?.name || 'Operador').slice(0,160),
        role: info?.role === 'admin' ? 'admin' : 'operator',
        sections,
        places
      });
    }
  }
  return map;
}
function auth(req) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7).trim() : '';
  if (!token) return null;
  const digest = crypto.createHash('sha256').update(token).digest('hex');
  const builtin = BUILTIN_TOKEN_HASHES.get(digest);
  if (builtin) return {...builtin, tokenHash:digest.slice(0,10)};
  const legacy = parseLegacyOperatorsForDev().get(token);
  return legacy ? {...legacy, tokenHash:digest.slice(0,10)} : null;
}
function canWrite(user, section) {
  return !!user && (user.role === 'admin' || user.sections.includes('*') || user.sections.includes(Number(section)));
}
function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});
  res.end(body);
}
function text(res, status, body, type='text/plain; charset=utf-8') { res.writeHead(status, {'content-type':type,'x-content-type-options':'nosniff'}); res.end(body); }
async function readBody(req) {
  let size=0, chunks=[];
  for await (const c of req) { size += c.length; if (size > 1024*1024) throw new Error('body_too_large'); chunks.push(c); }
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {};
}

const clients = new Set();
function broadcast(event='update', data={}) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) { try { res.write(payload); } catch { clients.delete(res); } }
}

async function applyOfficialDecoded({section,artifact,parsed}) {
  const sec=Number(section), placeId=sectionToPlace.get(sec);
  if(!placeId || !parsed || !Array.isArray(parsed.recognizedCargos)) return;
  const actor='TSE Automático';
  const now=new Date().toISOString();
  for(const cargoData of parsed.recognizedCargos) {
    const cargo=String(cargoData.cargo||''); if(!allowedCargos.has(cargo)) continue;
    const payload=cleanPayload({
      candidatos:(cargoData.candidatos||[]).map(c=>({numero:String(c.numero||''),nome:`Candidato ${c.numero||''}`,partido:'',votos:Number(c.votos||0)})),
      legendas:(cargoData.legendas||[]).map(l=>({numero:String(l.numero||''),votos:Number(l.votos||0)})),
      brancos:Number(cargoData.brancos||0),nulos:Number(cargoData.nulos||0),comparecimento:Number(parsed.meta?.COMP||0),
      fonte:'TSE · BU oficial decodificado',
      buMeta:{zona:Number(parsed.meta?.ZONA||0),secao:sec,secaoOriginal:Number(parsed.meta?.SECA||sec),municipioCodigo:String(parsed.meta?.MUNI||''),urnaId:String(parsed.meta?.IDUE||''),pleito:String(parsed.meta?.PLEI||''),turno:Number(parsed.meta?.TURN||0),versaoQr:String(parsed.meta?.VRQR||''),hash:String(parsed.meta?.HASH||''),assinaturaPresente:!!parsed.meta?.ASSI,qrParts:1,qrTotal:Number(parsed.meta?.qrTotal||1),parsedAt:now,votosNominais:Number(cargoData.nominais||0),votosLegenda:Number(cargoData.votosLegenda||0)},
      officialMeta:artifact, sourceKind:'tse'
    },actor,'tse');
    const before=getRow.get(sec,cargo)||null;
    if(before?.official_payload_json && comparisonOf(before.official_payload_json,payload).equal) continue;
    const officialJson=JSON.stringify(payload), localJson=before?.local_payload_json||null;
    const status=localJson ? (comparisonOf(localJson,officialJson).equal?'verified':'divergent') : 'tse_official';
    const publicJson=officialJson;
    if(before) updateRow.run(placeId,localJson,officialJson,publicJson,status,now,actor,sec,cargo);
    else insertRow.run(sec,cargo,placeId,localJson,officialJson,publicJson,status,now,actor);
    const after=getRow.get(sec,cargo);
    insertAudit.run('tse_auto_official',sec,cargo,placeId,actor,before?JSON.stringify(before):null,JSON.stringify(after),now);
    broadcast('update',{section:sec,cargo,placeId,verificationStatus:status,updatedAt:now,source:'tse_auto'});
  }
}
setInterval(()=>{ for(const res of clients) { try {res.write(': ping\n\n')} catch {clients.delete(res)} } }, 25000).unref();

const tseSync = createTseSync({db, locations, broadcast, runtimeDir:RUNTIME, onOfficialDecoded:applyOfficialDecoded});
tseSync.start();

const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon','.webmanifest':'application/manifest+json; charset=utf-8'};
async function serveStatic(req,res,pathname) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  rel = decodeURIComponent(rel).replace(/\\/g,'/');
  const target = path.normalize(path.join(PUBLIC, rel));
  if (!target.startsWith(PUBLIC)) return text(res,403,'Forbidden');
  try {
    const st = await stat(target); if (!st.isFile()) throw new Error('not_file');
    const data = await readFile(target);
    res.writeHead(200, {'content-type':mime[path.extname(target)]||'application/octet-stream','cache-control': (path.extname(target)==='.html'||path.basename(target)==='service-worker.js'||path.extname(target)==='.webmanifest')?'no-cache':'public, max-age=300','x-frame-options':'SAMEORIGIN','referrer-policy':'strict-origin-when-cross-origin','x-content-type-options':'nosniff'});
    res.end(data);
  } catch { text(res,404,'Not found'); }
}

const server = http.createServer(async (req,res) => {
  const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const p = u.pathname;
  try {
    if (p === '/api/health') return json(res,200,{ok:true,service:'Central Eleitoral Colméia 2026',version:'0.19.0',time:new Date().toISOString(),db:'sqlite',sse:true,persistentStorage:!!(process.env.DATA_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH),authConfigured:true,authMode:'hashed_section_keys',tse:{phase:tseSync.getStatus().phase,summary:tseSync.getStatus().summary}});
    if (p === '/api/whoami') {
      const user=auth(req); if(!user) return json(res,401,{ok:false,error:'unauthorized'});
      return json(res,200,{ok:true,user:{name:user.name,role:user.role,sections:user.sections,places:user.places}});
    }
    if (p === '/api/snapshot') return json(res,200,{ok:true,...snapshot()});
    if (p === '/api/tse/status') return json(res,200,{ok:true,...tseSync.getStatus()});
    if (p === '/api/tse/section') {
      const section=Number(u.searchParams.get('section'));
      const evidence=tseSync.getSectionEvidence(section);
      if(!evidence) return json(res,404,{ok:false,error:'section_not_found'});
      return json(res,200,{ok:true,...evidence});
    }
    if (p === '/api/tse/comparison') {
      const section=Number(u.searchParams.get('section')); if(!sectionToPlace.has(section)) return json(res,404,{ok:false,error:'section_not_found'});
      const items={}; let verified=0, divergent=0, pending=0;
      for(const cargo of allowedCargos) {
        const row=getRow.get(section,cargo);
        if(!row){items[cargo]={status:'waiting_local_and_tse',comparison:null};pending++;continue;}
        const local=row.local_payload_json?safeJson(row.local_payload_json):null, official=row.official_payload_json?safeJson(row.official_payload_json):null;
        const cmp=local&&official?comparePayloads(local,official):null;
        const status=row.verification_status; if(status==='verified')verified++; else if(status==='divergent')divergent++; else pending++;
        items[cargo]={status,comparison:cmp?{equal:cmp.equal,differences:cmp.differences,summary:cmp.summary}:null,localAvailable:!!local,officialAvailable:!!official};
      }
      return json(res,200,{ok:true,section,summary:{verified,divergent,pending,total:allowedCargos.size},items});
    }
    if (p === '/api/tse/refresh' && req.method === 'POST') {
      const user=auth(req); if(!user || user.role!=='admin') return json(res,403,{ok:false,error:'admin_required'});
      const status=await tseSync.refresh({manual:true});
      return json(res,200,{ok:true,...status});
    }
    if (p === '/api/stream') {
      res.writeHead(200, {'content-type':'text/event-stream','cache-control':'no-cache, no-transform','connection':'keep-alive','x-accel-buffering':'no'});
      res.write(`event: hello\ndata: ${JSON.stringify({time:new Date().toISOString()})}\n\n`);
      clients.add(res); req.on('close',()=>clients.delete(res)); return;
    }
    if (p === '/api/admin/overview') {
      const user=auth(req); if(!user || user.role!=='admin') return json(res,403,{ok:false,error:'admin_required'});
      return json(res,200,{ok:true,...adminOverview()});
    }
    if (p === '/api/admin/export') {
      const user=auth(req); if(!user || user.role!=='admin') return json(res,403,{ok:false,error:'admin_required'});
      const overview=adminOverview();
      return json(res,200,{ok:true,overview,audit:auditRows.all(200).map(x=>({id:x.id,action:x.action,section:x.section,cargo:x.cargo,placeId:x.place_id,actor:x.actor,createdAt:x.created_at}))});
    }
    if (p === '/api/audit') {
      const user=auth(req); if(!user || user.role!=='admin') return json(res,403,{ok:false,error:'forbidden'});
      const limit=Math.max(1,Math.min(200,Number(u.searchParams.get('limit')||50)));
      return json(res,200,{ok:true,items:auditRows.all(limit).map(x=>({...x,before:x.before_json?safeJson(x.before_json):null,after:x.after_json?safeJson(x.after_json):null,before_json:undefined,after_json:undefined}))});
    }
    if (p === '/api/results' && req.method === 'POST') {
      const user=auth(req); if(!user) return json(res,401,{ok:false,error:'unauthorized'});
      const body=await readBody(req);
      const section=Number(body.section), cargo=String(body.cargo||''), placeId=sectionToPlace.get(section);
      if(!placeId || !allowedCargos.has(cargo)) return json(res,400,{ok:false,error:'invalid_section_or_cargo'});
      if(!canWrite(user,section)) return json(res,403,{ok:false,error:'operator_not_allowed_for_section',section,placeId});
      const sourceKind = body.sourceKind === 'tse' && user.role === 'admin' ? 'tse' : 'local';
      const payload=cleanPayload(body,user.name,sourceKind);
      const now=new Date().toISOString();
      const before=getRow.get(section,cargo) || null;
      let localJson=before?.local_payload_json||null, officialJson=before?.official_payload_json||null, publicJson, status;
      if(sourceKind==='tse') {
        officialJson=JSON.stringify(payload);
        if(localJson) status = comparisonOf(localJson,officialJson).equal ? 'verified' : 'divergent';
        else status='tse_official';
        publicJson=officialJson;
      } else {
        localJson=JSON.stringify(payload);
        if(officialJson) {
          status = comparisonOf(localJson,officialJson).equal ? 'verified' : 'divergent';
          publicJson=officialJson;
        } else { status='local_pending'; publicJson=localJson; }
      }
      if(before) updateRow.run(placeId,localJson,officialJson,publicJson,status,now,user.name,section,cargo);
      else insertRow.run(section,cargo,placeId,localJson,officialJson,publicJson,status,now,user.name);
      const after=getRow.get(section,cargo);
      insertAudit.run(before?'update':'create',section,cargo,placeId,`${user.name}#${user.tokenHash}`,before?JSON.stringify(before):null,JSON.stringify(after),now);
      broadcast('update',{section,cargo,placeId,verificationStatus:status,updatedAt:now});
      return json(res,200,{ok:true,result:rowToPayload(after),verificationStatus:status});
    }
    if (p === '/api/results' && req.method === 'DELETE') {
      const user=auth(req); if(!user || user.role!=='admin') return json(res,403,{ok:false,error:'admin_required'});
      const section=Number(u.searchParams.get('section')), cargo=String(u.searchParams.get('cargo')||'');
      const before=getRow.get(section,cargo); if(!before) return json(res,404,{ok:false,error:'not_found'});
      deleteRow.run(section,cargo);
      const now=new Date().toISOString(); insertAudit.run('delete',section,cargo,before.place_id,`${user.name}#${user.tokenHash}`,JSON.stringify(before),null,now);
      broadcast('delete',{section,cargo,updatedAt:now});
      return json(res,200,{ok:true});
    }
    if (p.startsWith('/api/')) return json(res,404,{ok:false,error:'not_found'});
    return serveStatic(req,res,p);
  } catch (err) {
    console.error(err);
    return json(res, err?.message==='body_too_large'?413:500, {ok:false,error: err?.message || 'server_error'});
  }
});
server.listen(PORT,'0.0.0.0',()=>{
  console.log(`Central Eleitoral Colméia 2026 em http://0.0.0.0:${PORT}`);
  console.log(`Banco SQLite: ${path.join(RUNTIME, 'central.sqlite')}`);
  if(!isProd && !process.env.ADMIN_TOKEN) console.log('DEV admin token: COLMEIA-ADMIN-DEMO');
  if(isProd) console.log('Autenticação: hashes SHA-256 de 29 seções + coordenação.');
  console.log('TSE: EA11/EA16/EA18 + preservação + decoder seguro + comparação automática ativos.');
  console.log('Coordenação: painel de 29 seções + auditoria + diferenças BU local x oficial ativas.');
  console.log('PWA V0.19: app instalável + shell offline + fila local deduplicada ativos.');
  if(isProd && !process.env.RAILWAY_VOLUME_MOUNT_PATH && !process.env.DATA_DIR) console.warn('AVISO: banco em armazenamento efêmero. Anexe um Volume antes do uso real.');
});
