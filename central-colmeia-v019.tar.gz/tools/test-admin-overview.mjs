import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const tmp = await mkdtemp(path.join(os.tmpdir(), 'colmeia-v018-'));
const port = 18818;
const child = spawn(process.execPath, [path.join(root, 'server.mjs')], {
  env: {...process.env, NODE_ENV:'development', DATA_DIR:tmp, PORT:String(port)},
  stdio:['ignore','pipe','pipe']
});
let logs=''; child.stdout.on('data',d=>logs+=d); child.stderr.on('data',d=>logs+=d);
const wait = ms => new Promise(r=>setTimeout(r,ms));
try {
  let health;
  for (let i=0;i<60;i++) {
    try { const r=await fetch(`http://127.0.0.1:${port}/api/health`); if(r.ok){health=await r.json();break;} } catch {}
    await wait(100);
  }
  if (!health || health.version!=='0.19.0') throw new Error('health/version failed');
  const denied=await fetch(`http://127.0.0.1:${port}/api/admin/overview`);
  if (denied.status!==403) throw new Error(`unauthenticated overview expected 403, got ${denied.status}`);
  const headers={authorization:'Bearer COLMEIA-ADMIN-DEMO'};
  const r=await fetch(`http://127.0.0.1:${port}/api/admin/overview`,{headers});
  if(!r.ok) throw new Error(`overview ${r.status}`);
  const j=await r.json();
  if(j.sectionsExpected!==29 || j.sections?.length!==29 || j.summary?.totalExpectedLocalCargos!==145) throw new Error('overview counts invalid');
  const exp=await fetch(`http://127.0.0.1:${port}/api/admin/export`,{headers});
  const ej=await exp.json(); if(!exp.ok || !ej.overview || !Array.isArray(ej.audit)) throw new Error('export failed');
  console.log('V0.19 admin overview: PASS — 29 sections, 145 cargo slots, admin-only export.');
} finally {
  child.kill('SIGTERM');
  await wait(100);
  await rm(tmp,{recursive:true,force:true});
}
