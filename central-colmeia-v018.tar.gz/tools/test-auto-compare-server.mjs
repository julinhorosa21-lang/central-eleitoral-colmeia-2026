import http from 'node:http';
import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';

const payloadBu = Buffer.from('QRBU:1:1 MUNI:12345 ZONA:16 SECA:1 COMP:100 CARG:1 10:50 20:40 BRAN:3 NULO:7 TOTC:100 CARG:3 15:55 30:35 BRAN:4 NULO:6 TOTC:100 HASH:AA ASSI:BB');
const payloadSig = Buffer.from('ASSINATURA-SINTETICA');
const batchHash='ABCDEF0123456789', pleito='123', muni='12345';
const auxPath='/oficial/ele2026/arquivo-urna/123/dados/to/12345/0016/0001/p000123-to-m12345-z0016-s0001-aux.json';
const buName='p000123-to-m12345-z0016-s0001.bu', sigName='p000123-to-m12345-z0016-s0001.vscmr';
const mock=http.createServer((req,res)=>{
  const send=o=>{res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(o))};
  if(req.url==='/oficial/comum/config/ele-c.json') return send({c:'ele2026',pl:[{cd:pleito,dt:'04/10/2026',e:[{cd:'999',t:'1',nm:'Eleição Geral',abr:[{cp:[{cd:1},{cd:3}]}]}]}],arq:[{tp:'cs',dir:'<base>/<ambiente>/<ciclo>/config'}]});
  if(req.url==='/oficial/ele2026/config/to-p000123-cs.json') return send({abr:[{cd:'to',mu:[{nm:'Colméia',cd:muni,zon:[{cd:'16',sec:[{ns:1,da:'04/10/2026',ha:'17:01:02'}]}]}]}]});
  if(req.url===auxPath) return send({st:'Recebida',hashes:[{hash:batchHash,dr:'04/10/2026',hr:'17:01:02',st:'Recebido',arq:[{nm:buName,tp:'BU'},{nm:sigName,tp:'Assinatura'}]}]});
  if(req.url===`/oficial/ele2026/arquivo-urna/123/dados/to/12345/0016/0001/${batchHash}/${buName}`){res.writeHead(200,{'content-type':'application/octet-stream','content-length':payloadBu.length});return res.end(payloadBu)}
  if(req.url===`/oficial/ele2026/arquivo-urna/123/dados/to/12345/0016/0001/${batchHash}/${sigName}`){res.writeHead(200,{'content-type':'application/octet-stream','content-length':payloadSig.length});return res.end(payloadSig)}
  res.writeHead(404);res.end('not found');
});
await new Promise(r=>mock.listen(0,'127.0.0.1',r));
const mockPort=mock.address().port;
const freePort=await new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p))})});
const runtime=await mkdtemp(path.join(os.tmpdir(),'colmeia-v018-auto-'));
const app=spawn(process.execPath,['server.mjs'],{cwd:path.resolve(import.meta.dirname,'..'),env:{...process.env,NODE_ENV:'development',PORT:String(freePort),DATA_DIR:runtime,TSE_BASE_URL:`http://127.0.0.1:${mockPort}`,TSE_POLL_SECONDS:'999'},stdio:['ignore','pipe','pipe']});
let logs=''; app.stdout.on('data',d=>logs+=d); app.stderr.on('data',d=>logs+=d);
const base=`http://127.0.0.1:${freePort}`;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitHealth(){for(let i=0;i<60;i++){try{const r=await fetch(base+'/api/health');if(r.ok)return await r.json()}catch{}await sleep(100)}throw new Error('server_health_timeout\n'+logs)}
try{
  const health=await waitHealth(); if(health.version!=='0.18.0') throw new Error('versão inesperada '+health.version);
  const local={section:1,cargo:'presidente',sourceKind:'local',candidatos:[{numero:'10',votos:50},{numero:'20',votos:40}],legendas:[],brancos:3,nulos:7,comparecimento:100,fonte:'Teste local'};
  const post=await fetch(base+'/api/results',{method:'POST',headers:{'content-type':'application/json','authorization':'Bearer COLMEIA-ADMIN-DEMO'},body:JSON.stringify(local)});
  if(!post.ok) throw new Error('POST local falhou '+post.status+' '+await post.text());
  let cmp=null;
  for(let i=0;i<80;i++){
    const r=await fetch(base+'/api/tse/comparison?section=1'); if(r.ok){cmp=await r.json(); if(cmp.items?.presidente?.officialAvailable) break;} await sleep(100);
  }
  if(!cmp?.items?.presidente?.officialAvailable) throw new Error('oficial não chegou\n'+logs);
  if(cmp.items.presidente.status!=='verified' || cmp.items.presidente.comparison?.equal!==true) throw new Error('presidente deveria estar verified '+JSON.stringify(cmp.items.presidente));
  if(cmp.items.governador.status!=='tse_official') throw new Error('governador deveria estar tse_official '+JSON.stringify(cmp.items.governador));
  // agora força uma diferença local e confirma que o motor marca divergência.
  local.candidatos=[{numero:'10',votos:49},{numero:'20',votos:41}];
  const post2=await fetch(base+'/api/results',{method:'POST',headers:{'content-type':'application/json','authorization':'Bearer COLMEIA-ADMIN-DEMO'},body:JSON.stringify(local)});
  if(!post2.ok) throw new Error('POST divergente falhou '+post2.status);
  const r2=await fetch(base+'/api/tse/comparison?section=1'); const cmp2=await r2.json();
  if(cmp2.items.presidente.status!=='divergent' || cmp2.items.presidente.comparison?.equal!==false || !(cmp2.items.presidente.comparison?.differences?.length>0)) throw new Error('divergência não detectada '+JSON.stringify(cmp2.items.presidente));
  console.log('V0.18 server auto-compare: PASS — local igual -> verified; local diferente -> divergent; oficial sem local -> tse_official.');
} finally {
  app.kill('SIGTERM'); await sleep(150); mock.close(); await rm(runtime,{recursive:true,force:true});
}
