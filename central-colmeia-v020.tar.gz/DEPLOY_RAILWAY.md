# Publicar a Central Eleitoral Colméia 2026 — V0.20 na Railway

Esta versão usa Node.js 22 + Dockerfile e mantém o banco/artefatos oficiais em armazenamento persistente.

## Configuração atual do projeto

- Healthcheck: `/api/health`
- Porta: usar `PORT` fornecida automaticamente pela Railway.
- Volume persistente: `/data`.
- O servidor detecta `RAILWAY_VOLUME_MOUNT_PATH` e grava nele:
  - `central.sqlite`;
  - `tse/artifacts/...` com BU/IMGBU/VOTA/assinaturas oficiais preservados.
- Em produção, as 29 chaves de seção + coordenação são comparadas por hashes SHA-256 incorporados ao servidor. As chaves em texto puro não devem ser publicadas.

## Variáveis opcionais do conector TSE

- `TSE_BASE_URL=https://resultados.tse.jus.br`
- `TSE_AMBIENTE=oficial`
- `TSE_POLL_SECONDS=60`
- `TSE_MAX_ARTIFACT_BYTES=26214400`

Os padrões já funcionam sem configurar essas variáveis.

## Verificação após deploy

1. Acessar `/api/health` e conferir `ok: true`, `version: 0.20.0` e `persistentStorage: true`.
2. Acessar `/api/tse/status` e conferir o estado do conector.
3. Acessar `/api/tse/section?section=49` para conferir a API de evidência e estado do decoder.
4. Acessar `/api/tse/comparison?section=49` para conferir a API de comparação.
5. Validar que uma chave de operador continua limitada à sua própria seção.
6. Reiniciar/reimplantar o serviço e confirmar que o banco permanece no Volume.

## Segurança

- Nunca publicar `.env`, banco SQLite ou o PDF/arquivo com as chaves dos operadores.
- Não inferir nomes de arquivos de urna. A V0.18 usa somente os nomes e hashes fornecidos pelo EA18.
- A presença/download de um BU oficial não equivale a conferência voto a voto. `verified` só é produzido depois de um payload oficial estruturado ser comparado com o local sem diferenças.
- Binário oficial não reconhecido permanece preservado com hashes e estado `awaiting_2026_binary_spec`; nunca é decodificado por suposição.


## Hotfix V0.16.1 — autenticação de operador
- Remove persistência da chave no navegador (`localStorage`).
- Recarregar ou fechar a página exige nova chave.
- Sessão em memória expira após 15 minutos sem atividade.
- Leitor/colar QR e painel de lançamento exigem autenticação antes de abrir.
- O backend continua exigindo `Authorization` em toda gravação.
- Em queda de internet, apenas uma sessão já validada e ainda aberta pode enfileirar dados; após recarga offline, não há acesso à área restrita.

## V0.20
O deploy deve manter HTTPS no domínio Railway, requisito para Service Worker/PWA. Não remova o volume `/data`. O `service-worker.js` e o `manifest.webmanifest` são servidos com `Cache-Control: no-cache` para facilitar atualização segura do app.

Após publicar, valide também `/api/admin/overview` e `/api/admin/section-detail?section=49` usando a chave da coordenação. As duas rotas administrativas devem rejeitar acesso sem perfil administrativo.
