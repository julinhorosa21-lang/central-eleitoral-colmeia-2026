# Central Eleitoral Colméia 2026 — V0.20

A V0.20 consolida a central compartilhada e transforma o painel da coordenação em uma tela operacional para o dia da apuração.

## O que já funciona

- Banco SQLite central com uma linha por seção + cargo.
- API pública de leitura (`/api/snapshot`).
- Atualização em tempo real entre navegadores por Server-Sent Events (`/api/stream`).
- Operadores autenticados por chave.
- Permissão por seção receptora: cada operador possui uma chave limitada a uma única seção.
- Coordenação com acesso administrativo.
- Auditoria: criação, correção e exclusão ficam registradas.
- Dados locais de BU e dados oficiais do TSE são armazenados separadamente.
- Status: `local_pending`, `tse_official`, `verified` ou `divergent`.
- Se o servidor cair, o navegador pode guardar um envio na fila local e tentar sincronizar ao voltar.
- A interface V0.10 foi preservada: mapa, locais, candidatos, fotos e apuração por cargo.

## Rodar no computador

Requer Node.js 22 ou superior.

```bash
npm start
```

Abra:

`http://localhost:8787`

Em modo de desenvolvimento, se nenhuma chave for configurada, a chave administrativa é:

`COLMEIA-ADMIN-DEMO`

**Nunca use essa chave em produção.**

## Criar chaves reais dos operadores

```bash
npm run tokens
```

O comando gera:

- uma chave da coordenação;
- uma chave diferente para cada uma das 29 seções receptoras;
- um JSON para colocar em `OPERATOR_TOKENS`.

As chaves não devem ser colocadas dentro de `index.html`, GitHub público ou arquivos enviados ao público.

## Variáveis de ambiente

Veja `.env.example`.

- `PORT`
- `ADMIN_TOKEN`
- `OPERATOR_TOKENS`

## Banco

O arquivo é criado em:

`runtime/central.sqlite`

Em produção, essa pasta precisa estar em armazenamento persistente. Não use sistema de arquivos efêmero para o banco.

## Arquitetura

```
Público ────────┐
Operadores ─────┼──> servidor Node ──> SQLite
Coordenação ────┘         │
                          └── SSE -> atualização ao vivo

TSE EA11/EA16/EA18 ───────> descoberta/download BU oficial -> decoder seguro -> comparação local × oficial
```

## Próximas etapas

1. Validar o decoder binário oficial assim que a especificação/amostras 2026 correspondentes forem confirmadas pelo TSE.
2. Criar a página pública de transparência e metodologia da Central.
3. Reforçar segurança operacional, rate limit e trilha de auditoria.
4. Executar simulações completas de eleição antes do primeiro turno.

## Observação

A Central é um projeto independente. Quando integrarmos os dados do TSE, o app deve diferenciar claramente resultados recebidos localmente por BU e resultados oficiais da Justiça Eleitoral.

## V0.12 — pronta para Railway

- Detecta automaticamente `RAILWAY_VOLUME_MOUNT_PATH` para persistir o SQLite.
- Servidor escuta em `0.0.0.0` e usa a variável `PORT` da hospedagem.
- `/api/health` informa se armazenamento persistente e autenticação estão configurados.
- Inclui `DEPLOY_RAILWAY.md`, `.dockerignore` e `npm run check`.


## V0.13 — leitura de QR do Boletim de Urna

- Leitura pela câmera do navegador em HTTPS.
- Captura automática de BUs com múltiplos QR Codes e remontagem por `QRBU:parte:total`.
- Interpretação estrutural dos cargos 1, 3, 5, 6 e 7 das eleições gerais.
- Preenchimento automático de candidatos, brancos, nulos e comparecimento.
- Votos de legenda preservados para cargos proporcionais.
- Botão para revisar um cargo ou salvar todos os cargos lidos.
- Fingerprint SHA-256 local do conteúdo remontado e metadados do BU gravados junto ao resultado.
- A V0.13 **não valida criptograficamente a assinatura do QR**; ela apenas registra a presença de HASH/ASSI. A validação por chaves públicas do TSE fica para etapa posterior.


## V0.14 — operadores por seção

- 29 chaves de operador, uma para cada seção receptora ativa de Colméia.
- A seção 49 usa uma única chave e representa também a seção agregada 113.
- 1 chave administrativa geral da coordenação, com acesso a todas as seções.
- O servidor rejeita gravações em seção diferente da autorizada pela chave.
- A interface mostra claramente a seção autorizada e trava o seletor para operadores de seção.
- Ao ler um QR de BU de outra seção, o app bloqueia o envio antes da publicação.
- O primeiro acesso da chave precisa ser validado online. Desde o hotfix V0.16.1, a credencial não é persistida no navegador; somente uma sessão já aberta e ainda válida pode operar a fila offline.


## V0.14.1 — autenticação por hash
Em produção, as 29 chaves de seção e a chave administrativa são comparadas por SHA-256. As chaves em texto puro não ficam no repositório nem nas variáveis da Railway. As chaves entregues aos operadores permanecem as mesmas do arquivo confidencial gerado para V0.14.

## V0.15 — conector oficial TSE (EA11 + EA16 + EA18)

- O servidor consulta o arquivo público `ele-c.json` (EA11) e procura automaticamente o pleito de 4/10/2026.
- Quando o TSE publicar o pleito, o conector descobre ciclo, código do pleito e eleições sem números fixados manualmente.
- O EA16 é usado para localizar Colméia, a 16ª Zona Eleitoral, as 29 seções receptoras e eventuais seções agregadas.
- O EA18 só é consultado quando o próprio EA16 informa data/hora do arquivo auxiliar, reduzindo requisições 404.
- `/api/tse/status` mostra o estado da sincronização sem exigir login.
- `/api/tse/refresh` permite à coordenação forçar uma atualização.
- O TSE é tratado como fonte oficial separada. A V0.15 ainda **não substitui** o BU local por totais municipais do EA20, pois isso perderia a granularidade por seção.
- A próxima etapa técnica é interpretar os arquivos oficiais de BU apontados pelo EA18 e comparar seção a seção com o QR capturado localmente.


## V0.16 — artefato oficial do BU por seção

- O EA18 passa a ser interpretado também como catálogo dos arquivos de urna publicados para cada seção.
- A central usa apenas o hash e o nome de arquivo fornecidos pelo próprio EA18 para formar a URL; não tenta adivinhar nomes.
- Arquivos BU e de assinatura listados são baixados para o volume persistente quando disponíveis.
- Cada arquivo preservado recebe SHA-256 e SHA-512 calculados pela central, além de tamanho e horário do download.
- `GET /api/tse/section?section=N` expõe a evidência pública da seção sem revelar caminhos internos do servidor.
- A interface diferencia “EA18 recebido”, “BU listado” e “BU oficial preservado”.
- A presença do arquivo oficial **não altera** `local_pending` para `verified`: a conferência voto a voto só ocorrerá depois de decodificar o `.bu` oficial e comparar seu conteúdo.
- Testes sintéticos cobrem a cadeia EA11 -> EA16 -> EA18 -> download de BU/assinatura, persistência e SHA-256.


## Hotfix V0.16.1 — autenticação de operador
- Remove persistência da chave no navegador (`localStorage`).
- Recarregar ou fechar a página exige nova chave.
- Sessão em memória expira após 15 minutos sem atividade.
- Leitor/colar QR e painel de lançamento exigem autenticação antes de abrir.
- O backend continua exigindo `Authorization` em toda gravação.
- Em queda de internet, apenas uma sessão já validada e ainda aberta pode enfileirar dados; após recarga offline, não há acesso à área restrita.


## V0.17 — Painel da Coordenação

- painel administrativo protegido pela chave geral;
- visão das 29 seções e dos cinco cargos esperados por seção;
- progresso de BU local, EA18 e preservação do BU oficial;
- alertas de parcialidade e divergência;
- atualização manual do conector TSE;
- auditoria administrativa e exportação JSON;
- nenhuma suposição de compatibilidade binária entre o BU ASN.1 de 2024 e 2026. A comparação voto a voto só será habilitada após confirmação da especificação 2026.


## V0.18 — conferência automática BU local × TSE

- Introduz um motor de comparação canônica entre o lançamento local e um payload oficial estruturado.
- Compara, por cargo, votos por número de candidato, votos de legenda, brancos, nulos, comparecimento e total de votos válidos.
- Quando todos os campos comparáveis coincidem, o cargo passa para `verified`; qualquer diferença passa para `divergent` e os dois payloads permanecem armazenados separadamente.
- `GET /api/tse/comparison?section=N` apresenta o estado de cada cargo e, quando houver divergência, a lista estruturada de diferenças.
- O conector preserva BU, IMGBU, VOTA e assinatura quando listados no EA18; o decoder automático só consome conteúdo que reconhece com segurança como QRBU textual ou JSON estruturado.
- Arquivo `.bu` binário não reconhecido recebe estado `awaiting_2026_binary_spec`. Ele continua preservado com hashes, mas **não** produz uma falsa marca de conferência.
- O Painel da Coordenação passa a mostrar quantas seções possuem artefato oficial estruturado e quantos cargos já foram efetivamente conferidos.
- Testes automatizados cobrem igualdade, divergência detalhada, rejeição segura de binário desconhecido, fluxo sintético EA11 → EA16 → EA18 e integração ponta a ponta do servidor.

A V0.18 deliberadamente separa três fatos diferentes: **arquivo oficial encontrado**, **arquivo oficial decodificável** e **conteúdo local conferido**. Somente o terceiro autoriza o status `verified`.

## V0.19 — PWA e operação offline

- instalável no Android/Chrome e navegadores compatíveis;
- manifesto e ícones próprios;
- Service Worker com app shell offline;
- APIs administrativas e de resultados nunca são cacheadas;
- fila offline deduplicada por seção + cargo;
- reenvio após reconexão e autenticação válida;
- leitor QR preparado para uso offline depois do cache inicial;
- atualização do app com aviso ao usuário;
- chaves continuam somente em memória e não são salvas pelo PWA.

Veja `V019_PWA_OFFLINE.md` para as regras de segurança e limitações offline.


## V0.20 — painel operacional da coordenação

- busca por seção ou local;
- filtros por região e situação;
- ordenação por prioridade, seção, atualização recente ou tempo aguardando;
- fila de atenção que destaca primeiro divergências, depois BU parcial e ausência de BU local após o início da apuração;
- detalhe administrativo por seção com BU local e payload oficial/TSE lado a lado;
- diferenças estruturadas por cargo, candidato/legenda e totais;
- auditoria recente da seção com identificadores de credencial redigidos na API;
- seção 49 continua representando a agregada 113;
- nenhuma ausência de dado oficial é rotulada como divergência.

Veja `COORDENACAO_V020.md` para as regras operacionais do painel.
