import http from 'node:http';
import crypto from 'node:crypto';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { createTseSync } from '../tse-sync.mjs';

const payloadBu = Buffer.from('QRBU:1:1 MUNI:12345 ZONA:16 SECA:1 COMP:100 CARG:1 10:50 20:40 BRAN:3 NULO:7 TOTC:100 CARG:3 15:55 30:35 BRAN:4 NULO:6 TOTC:100 HASH:AA ASSI:BB');
const payloadSig = Buffer.from('ASSINATURA-SINTETICA');
const batchHash = 'ABCDEF0123456789';
const pleito = '123';
const muni = '12345';
const auxPath = '/oficial/ele2026/arquivo-urna/123/dados/to/12345/0016/0001/p000123-to-m12345-z0016-s0001-aux.json';
const buName = 'p000123-to-m12345-z0016-s0001.bu';
const sigName = 'p000123-to-m12345-z0016-s0001.vscmr';

const server = http.createServer((req,res)=>{
  const sendJson = obj => {res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(obj))};
  if(req.url==='/oficial/comum/config/ele-c.json') return sendJson({
    c:'ele2026',
    pl:[{cd:pleito,dt:'04/10/2026',e:[{cd:'999',t:'1',nm:'Eleição Geral',abr:[{cp:[{cd:1},{cd:3}]}]}]}],
    arq:[{tp:'cs',dir:'<base>/<ambiente>/<ciclo>/config'}]
  });
  if(req.url==='/oficial/ele2026/config/to-p000123-cs.json') return sendJson({abr:[{cd:'to',mu:[{nm:'Colméia',cd:muni,zon:[{cd:'16',sec:[{ns:1,da:'04/10/2026',ha:'17:01:02'}]}]}]}]});
  if(req.url===auxPath) return sendJson({st:'Recebida',hashes:[{hash:batchHash,dr:'04/10/2026',hr:'17:01:02',st:'Recebido',arq:[{nm:buName,tp:'BU'},{nm:sigName,tp:'Assinatura'}]}]});
  if(req.url===`/oficial/ele2026/arquivo-urna/123/dados/to/12345/0016/0001/${batchHash}/${buName}`){res.writeHead(200,{'content-type':'application/octet-stream','content-length':payloadBu.length});return res.end(payloadBu)}
  if(req.url===`/oficial/ele2026/arquivo-urna/123/dados/to/12345/0016/0001/${batchHash}/${sigName}`){res.writeHead(200,{'content-type':'application/octet-stream','content-length':payloadSig.length});return res.end(payloadSig)}
  res.writeHead(404);res.end('not found');
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const port=server.address().port;
const runtime=await mkdtemp(path.join(os.tmpdir(),'colmeia-tse-v016-'));
const db=new DatabaseSync(':memory:');
const locations={locais:[{id:'teste',secoes:[1]}]};
const decoded=[];
const sync=createTseSync({db,locations,runtimeDir:runtime,baseUrl:`http://127.0.0.1:${port}`,pollSeconds:999,onOfficialDecoded:async x=>decoded.push(x)});
try{
  const status=await sync.refresh({manual:true});
  if(status.phase!=='ready') throw new Error(`fase inesperada: ${status.phase} ${status.lastError||''}`);
  if(status.summary.officialBuDownloaded!==1) throw new Error('BU sintético não foi baixado');
  if(status.summary.signaturesDownloaded!==1) throw new Error('assinatura sintética não foi baixada');
  if(status.summary.structuredOfficialReady!==1) throw new Error('BU textual sintético não foi decodificado');
  if(decoded.length!==1 || decoded[0].parsed.recognizedCargos.length!==2) throw new Error('callback de resultado oficial estruturado falhou');
  const evidence=sync.getSectionEvidence(1);
  const bu=evidence.officialBu.find(x=>x.downloadStatus==='downloaded');
  if(!bu) throw new Error('evidência de BU ausente');
  const expected=crypto.createHash('sha256').update(payloadBu).digest('hex');
  if(bu.sha256!==expected) throw new Error('SHA-256 divergente');
  const stored=await readFile(path.join(runtime,'tse','artifacts','0001',batchHash,buName));
  if(!stored.equals(payloadBu)) throw new Error('arquivo persistido divergente');
  console.log('OK: EA11 -> EA16 -> EA18 sintético');
  console.log('OK: download exato de BU + assinatura listados no EA18');
  console.log('OK: persistência e SHA-256 do BU oficial');
  console.log('OK: decoder seguro e callback de comparação automática');
} finally {
  sync.stop(); db.close(); server.close(); await rm(runtime,{recursive:true,force:true});
}
