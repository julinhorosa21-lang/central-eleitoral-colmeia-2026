import { readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const pub=path.join(root,'public');
function ok(cond,msg){if(!cond)throw new Error(msg);console.log('OK:',msg)}
const manifest=JSON.parse(readFileSync(path.join(pub,'manifest.webmanifest'),'utf8'));
const html=readFileSync(path.join(pub,'index.html'),'utf8');
const sw=readFileSync(path.join(pub,'service-worker.js'),'utf8');

ok(manifest.display==='standalone','manifest standalone');
ok(manifest.start_url?.startsWith('/'),'start_url same-origin');
ok(Array.isArray(manifest.icons)&&manifest.icons.some(x=>x.sizes==='192x192')&&manifest.icons.some(x=>x.sizes==='512x512'),'ícones 192 e 512 declarados');
for(const icon of manifest.icons) ok(existsSync(path.join(pub,icon.src.replace(/^\//,''))),`ícone existe: ${icon.src}`);
ok(html.includes('rel="manifest" href="/manifest.webmanifest"'),'manifest ligado ao HTML');
ok(html.includes("navigator.serviceWorker.register('/service-worker.js'"),'service worker registrado');
ok(html.includes("getOutbox().filter(x=>!(Number(x.section)===Number(payload.section)"),'fila offline deduplica seção/cargo');
ok(sw.includes("url.pathname.startsWith('/api/')"),'service worker não cacheia /api');
ok(sw.includes("req.method!=='GET'"),'service worker não intercepta gravações');
ok(sw.includes('html5-qrcode@2.3.8'),'leitor QR preparado para cache offline');
ok(sw.includes('tile.openstreetmap.org'),'tiles visitados podem ser reaproveitados offline');
console.log('PWA V0.20 pré-validada (recursos offline V0.19 preservados).');
