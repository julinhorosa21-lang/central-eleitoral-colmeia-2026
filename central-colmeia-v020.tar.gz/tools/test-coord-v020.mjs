import { spawn } from 'node:child_process';
import { mkdtemp, rm, readFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const tmp=await mkdtemp(path.join(os.tmpdir(),'colmeia-v020-detail-'));
const port=19020;
const child=spawn(process.execPath,[path.join(root,'server.mjs')],{env:{...process.env,NODE_ENV:'development',DATA_DIR:tmp,PORT:String(port)},stdio:['ignore','pipe','pipe']});
let logs=''; child.stdout.on('data',d=>logs+=d); child.stderr.on('data',d=>logs+=d);
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const base=`http://127.0.0.1:${port}`;
const headers={authorization:'Bearer COLMEIA-ADMIN-DEMO','content-type':'application/json'};
function assert(x,msg){if(!x)throw new Error(msg)}
try{
  for(let i=0;i<80;i++){try{const r=await fetch(base+'/api/health');if(r.ok)break}catch{} await wait(100)}
  let r=await fetch(base+'/api/admin/section-detail?section=49'); assert(r.status===403,'detail must be admin-only');
  const local={section:49,cargo:'presidente',sourceKind:'local',candidatos:[{numero:'13',nome:'Candidato 13',votos:100}],brancos:2,nulos:3,comparecimento:105,fonte:'Teste local'};
  r=await fetch(base+'/api/results',{method:'POST',headers,body:JSON.stringify(local)}); assert(r.ok,'local post failed');
  const official={...local,sourceKind:'tse',candidatos:[{numero:'13',nome:'Candidato 13',votos:101}],fonte:'Teste TSE'};
  r=await fetch(base+'/api/results',{method:'POST',headers,body:JSON.stringify(official)}); assert(r.ok,'official post failed'); const saved=await r.json(); assert(saved.verificationStatus==='divergent','expected divergent status');
  r=await fetch(base+'/api/admin/section-detail?section=49',{headers}); assert(r.ok,'detail failed'); const d=await r.json();
  assert(d.section===49 && d.aggregatedSections?.includes(113),'aggregated 113 missing');
  assert(d.items?.presidente?.local && d.items?.presidente?.official,'side-by-side payloads missing');
  assert(d.items.presidente.comparison?.equal===false,'comparison should differ');
  assert((d.items.presidente.comparison?.differences||[]).some(x=>x.kind==='candidate'&&x.numero==='13'),'candidate diff missing');
  assert((d.audit||[]).every(x=>!String(x.actor||'').includes('#')),'detail audit leaked token hash');
  r=await fetch(base+'/api/audit?limit=10',{headers}); const a=await r.json(); assert(r.ok && (a.items||[]).every(x=>!String(x.actor||'').includes('#')),'audit endpoint leaked token hash');
  r=await fetch(base+'/api/admin/overview',{headers}); const o=await r.json(); assert(r.ok,'overview failed');
  const s49=o.sections.find(x=>x.section===49); assert(s49?.verification?.divergent===1 && s49.needsAttention===true,'attention priority missing');
  assert(typeof o.summary.sectionsMissingLocal==='number' && typeof o.summary.sectionsPartialLocal==='number','new summary fields missing');
  const html=await readFile(path.join(root,'public/index.html'),'utf8');
  for(const id of ['coordSearch','coordRegionFilter','coordStatusFilter','coordSort','coordAttention','coordDetail']) assert(html.includes(`id="${id}"`),`UI missing ${id}`);
  assert(html.includes('/api/admin/section-detail?section='),'detail API not wired in UI');
  console.log('V0.20 coordenação: PASS — filtros, atenção, detalhe local x TSE e auditoria redigida.');
} finally {child.kill('SIGTERM');await wait(100);await rm(tmp,{recursive:true,force:true});}
