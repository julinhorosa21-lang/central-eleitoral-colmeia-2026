# V0.19 — PWA e operação offline

A V0.19 transforma a Central Eleitoral Colméia 2026 em uma Progressive Web App instalável.

## O que funciona offline
- interface principal já visitada/instalada;
- catálogo incorporado no HTML;
- parser QRBU (`bu-parser.js`);
- leitor por câmera quando a biblioteca já foi colocada no cache do app;
- leitura por conteúdo colado;
- resultados públicos já mantidos no cache local do navegador;
- lançamentos do operador em uma sessão já autenticada, entrando em fila local;
- tiles do mapa que já tiverem sido visitados podem reaparecer offline.

## Segurança preservada
A chave do operador **não é persistida** em `localStorage`, Cache Storage, manifesto nem Service Worker. Portanto:
- o primeiro login de uma nova sessão continua exigindo conexão com a central;
- se a conexão cair depois da autenticação, o operador pode continuar lançando enquanto a tela/sessão permanecer aberta;
- se o app for fechado/recarregado, será necessária nova autenticação online;
- endpoints `/api/*` e requisições de escrita nunca são armazenados pelo Service Worker.

## Fila offline
A fila é persistida no aparelho e deduplicada por `seção + cargo`: se o operador corrigir o mesmo cargo antes de reconectar, somente a versão mais recente daquele item permanece pendente. O envio é tentado quando a conexão volta e há uma sessão válida.

## Atualizações
Quando um novo Service Worker for instalado, o app mostra aviso de versão disponível e permite ativar a atualização.
