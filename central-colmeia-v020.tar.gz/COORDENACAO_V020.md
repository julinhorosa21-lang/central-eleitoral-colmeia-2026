# Painel da Coordenação — V0.20

A V0.20 transforma o painel administrativo em uma tela operacional para o dia da apuração.

## Prioridade

A fila de atenção ordena primeiro divergências, depois seções com BU parcial e, em seguida, seções sem BU após o início da apuração local. O sistema não declara que uma seção está oficialmente atrasada: mostra apenas o tempo operacional desde o primeiro BU local ou desde o último cargo de uma seção parcial.

## Filtros

É possível buscar por seção/local, filtrar por região e por situação, e ordenar por prioridade, seção, atualização recente ou tempo aguardando.

## Detalhe BU local × TSE

Cada seção abre um detalhe administrativo. Para cada um dos cinco cargos, o painel mostra:

- payload do BU recebido localmente;
- payload oficial estruturado, quando disponível;
- status de conferência;
- diferenças por candidato/legenda e totais;
- auditoria recente da seção.

A ausência de payload oficial estruturado não é tratada como divergência. Arquivos oficiais binários ainda não reconhecidos permanecem preservados sem uma falsa marca de conferência.

## Segurança

A rota de detalhe é exclusiva da coordenação. A API de auditoria não devolve o hash da credencial do operador no campo de ator, embora o registro interno continue disponível no banco para rastreabilidade técnica.
