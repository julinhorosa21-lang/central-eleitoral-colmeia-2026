# Conferência automática — V0.18

## Objetivo

Comparar o BU capturado localmente com um payload oficial derivado do artefato publicado pelo TSE, mantendo rastreabilidade e sem confundir “arquivo baixado” com “resultado conferido”.

## Estados

- `local_pending`: há lançamento local e ainda não há payload oficial estruturado para o cargo.
- `tse_official`: há payload oficial estruturado, mas ainda não há lançamento local.
- `verified`: local e oficial existem e todos os campos comparáveis coincidem.
- `divergent`: local e oficial existem e ao menos um campo é diferente.

## Campos comparados

- votos por número de candidato;
- votos de legenda por número do partido;
- brancos;
- nulos;
- comparecimento;
- total calculado de votos válidos (candidatos + legendas).

A ordem das linhas não interfere na comparação; votos repetidos para o mesmo número são consolidados antes da conferência.

## Decoder seguro

A V0.18 reconhece automaticamente apenas conteúdo estruturado que consiga validar de forma determinística como QRBU textual ou JSON com cargos reconhecíveis. Conteúdo binário desconhecido não é interpretado heurística ou especulativamente.

Quando o binário `.bu` de 2026 não for reconhecido, o arquivo e seus hashes continuam preservados e a seção permanece aguardando especificação/decoder confirmado.

## API

`GET /api/tse/comparison?section=N` retorna um item por cargo, com disponibilidade local/oficial, status e lista de diferenças.

## Regra de integridade

O payload oficial é o exibido publicamente quando disponível, mas o payload local original continua preservado no banco. Em divergência, nenhum dos dois é apagado ou mesclado. A auditoria registra a chegada automática do oficial.
