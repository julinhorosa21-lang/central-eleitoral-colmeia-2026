const num = v => Math.max(0, Number(v || 0) | 0);
const str = v => String(v ?? '').trim();

function keyed(items, numberKey='numero') {
  const out = new Map();
  for (const item of Array.isArray(items) ? items : []) {
    const k = str(item?.[numberKey]);
    if (!k) continue;
    out.set(k, (out.get(k) || 0) + num(item?.votos));
  }
  return out;
}

export function normalizeComparable(payload={}) {
  const cand = keyed(payload.candidatos);
  const leg = keyed(payload.legendas);
  return {
    candidatos: [...cand].sort((a,b)=>a[0].localeCompare(b[0], 'pt-BR', {numeric:true})).map(([numero,votos])=>({numero,votos})),
    legendas: [...leg].sort((a,b)=>a[0].localeCompare(b[0], 'pt-BR', {numeric:true})).map(([numero,votos])=>({numero,votos})),
    brancos: num(payload.brancos),
    nulos: num(payload.nulos),
    comparecimento: num(payload.comparecimento),
  };
}

function diffMap(kind, aItems, bItems) {
  const a = new Map(aItems.map(x=>[x.numero, x.votos]));
  const b = new Map(bItems.map(x=>[x.numero, x.votos]));
  const keys = [...new Set([...a.keys(), ...b.keys()])].sort((x,y)=>x.localeCompare(y,'pt-BR',{numeric:true}));
  return keys.flatMap(numero => {
    const local = a.get(numero) || 0, official = b.get(numero) || 0;
    return local === official ? [] : [{kind, numero, local, official, delta: official-local}];
  });
}

export function comparePayloads(localPayload, officialPayload) {
  if (!localPayload || !officialPayload) return {ready:false,equal:false,differences:[],summary:{differenceCount:0}};
  const local = normalizeComparable(localPayload), official = normalizeComparable(officialPayload);
  const differences = [
    ...diffMap('candidate', local.candidatos, official.candidatos),
    ...diffMap('legend', local.legendas, official.legendas),
  ];
  for (const field of ['brancos','nulos','comparecimento']) {
    if (local[field] !== official[field]) differences.push({kind:'field',field,local:local[field],official:official[field],delta:official[field]-local[field]});
  }
  const localValid = local.candidatos.reduce((s,x)=>s+x.votos,0) + local.legendas.reduce((s,x)=>s+x.votos,0);
  const officialValid = official.candidatos.reduce((s,x)=>s+x.votos,0) + official.legendas.reduce((s,x)=>s+x.votos,0);
  if (localValid !== officialValid) differences.push({kind:'field',field:'validos',local:localValid,official:officialValid,delta:officialValid-localValid});
  return {
    ready:true,
    equal:differences.length===0,
    local, official, differences,
    summary:{differenceCount:differences.length,localValid,officialValid}
  };
}

export function comparisonLabel(result) {
  if (!result?.ready) return 'waiting';
  return result.equal ? 'verified' : 'divergent';
}
