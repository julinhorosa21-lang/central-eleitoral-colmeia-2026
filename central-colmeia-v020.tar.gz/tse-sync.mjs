import crypto from 'node:crypto';
import path from 'node:path';
import { existsSync } from 'node:fs';
import { mkdir, rename, writeFile, readFile } from 'node:fs/promises';
import { decodeOfficialArtifact, DECODER_VERSION } from './official-bu-decoder.mjs';

const DEFAULT_BASE = 'https://resultados.tse.jus.br';
const DEFAULT_ENV = 'oficial';
const TARGET_DATE = '04/10/2026';
const TARGET_UF = 'to';
const TARGET_CITY = 'colmeia';
const TARGET_ZONE = '0016';
const DEFAULT_MAX_ARTIFACT_BYTES = 25 * 1024 * 1024;

const pad = (v, n) => String(v ?? '').replace(/\D/g, '').padStart(n, '0');
const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const nowIso = () => new Date().toISOString();

export function sanitizeArtifactName(value) {
  const raw = String(value || '').trim().replace(/\\/g, '/');
  const name = path.posix.basename(raw);
  if (!name || name === '.' || name === '..' || name !== raw || name.length > 240) return null;
  if (/\0/.test(name)) return null;
  return name;
}

export function classifyArtifact(fileName, fileType='') {
  const name = String(fileName || '').toLowerCase();
  const type = norm(fileType);
  if (name.endsWith('.bu') || type === 'bu' || type.includes('boletim de urna')) return 'BU';
  if (name.endsWith('.imgbu') || type.includes('imagem') && type.includes('bu')) return 'IMGBU';
  if (name.endsWith('.rdv') || type === 'rdv' || type.includes('registro digital')) return 'RDV';
  if (name.endsWith('.vota') || type === 'vota' || type.includes('arquivo de votacao')) return 'VOTA';
  if (name.endsWith('.logjez') || name.endsWith('.log') || type.includes('log')) return 'LOG';
  if (name.endsWith('.vscmr') || name.endsWith('.sig') || type.includes('assinatura')) return 'SIGNATURE';
  return 'OTHER';
}

export function artifactUrl({base, env, cycle, pleitoCode, uf=TARGET_UF, municipalityCode, zone=TARGET_ZONE, section, batchHash, fileName}) {
  const safeName = sanitizeArtifactName(fileName);
  const safeHash = String(batchHash || '').trim();
  if (!safeName || !safeHash || !/^[A-Za-z0-9_-]{8,256}$/.test(safeHash)) return null;
  const root = String(base || DEFAULT_BASE).replace(/\/+$/, '');
  const ambiente = String(env || DEFAULT_ENV).replace(/^\/+|\/+$/g, '');
  return `${root}/${ambiente}/${encodeURIComponent(String(cycle))}/arquivo-urna/${encodeURIComponent(String(pleitoCode))}/dados/${encodeURIComponent(String(uf).toLowerCase())}/${pad(municipalityCode,5)}/${pad(zone,4)}/${pad(section,4)}/${encodeURIComponent(safeHash)}/${encodeURIComponent(safeName)}`;
}

export function normalizeEa18(aux) {
  const batchesRaw = Array.isArray(aux?.hashes) ? aux.hashes : [];
  return batchesRaw.map((batch, idx) => {
    const hash = String(batch?.hash || batch?.h || '').trim();
    const filesRaw = Array.isArray(batch?.arq) ? batch.arq : (Array.isArray(batch?.arquivos) ? batch.arquivos : []);
    const files = filesRaw.map(file => {
      const name = sanitizeArtifactName(file?.nm ?? file?.nome ?? file?.nmarq ?? '');
      if (!name) return null;
      const type = String(file?.tp ?? file?.tipo ?? '');
      return {name, type, class: classifyArtifact(name, type)};
    }).filter(Boolean);
    return {
      hash,
      receivedDate: String(batch?.dr ?? batch?.dt ?? ''),
      receivedTime: String(batch?.hr ?? batch?.h ?? ''),
      status: String(batch?.st ?? ''),
      order: idx,
      files,
    };
  }).filter(batch => batch.hash);
}

export function createTseSync({db, locations, broadcast, baseUrl, ambiente, pollSeconds, runtimeDir, onOfficialDecoded}) {
  const base = String(baseUrl || process.env.TSE_BASE_URL || DEFAULT_BASE).replace(/\/+$/, '');
  const env = String(ambiente || process.env.TSE_AMBIENTE || DEFAULT_ENV).replace(/^\/+|\/+$/g, '');
  const configuredPoll = Math.max(30, Number(pollSeconds || process.env.TSE_POLL_SECONDS || 60));
  const artifactRoot = path.resolve(runtimeDir || process.env.DATA_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH || path.join(process.cwd(), 'runtime'), 'tse', 'artifacts');
  const maxArtifactBytes = Math.max(1024 * 1024, Number(process.env.TSE_MAX_ARTIFACT_BYTES || DEFAULT_MAX_ARTIFACT_BYTES));
  const localSections = [...new Set(locations.locais.flatMap(l => l.secoes.map(Number)))].sort((a,b)=>a-b);
  const cache = new Map();
  let running = false;
  let stopped = false;
  let timer = null;

  db.exec(`
    CREATE TABLE IF NOT EXISTS tse_sections (
      section INTEGER PRIMARY KEY,
      principal_section INTEGER NOT NULL,
      aggregated_json TEXT NOT NULL,
      ea16_available INTEGER NOT NULL DEFAULT 0,
      aux_date TEXT,
      aux_time TEXT,
      tse_status TEXT,
      hash_count INTEGER NOT NULL DEFAULT 0,
      last_hash_status TEXT,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tse_artifacts (
      section INTEGER NOT NULL,
      batch_hash TEXT NOT NULL,
      received_date TEXT,
      received_time TEXT,
      batch_status TEXT,
      file_name TEXT NOT NULL,
      file_type TEXT,
      file_class TEXT NOT NULL,
      file_url TEXT NOT NULL,
      download_status TEXT NOT NULL DEFAULT 'listed',
      local_path TEXT,
      size_bytes INTEGER,
      sha256 TEXT,
      sha512 TEXT,
      downloaded_at TEXT,
      last_error TEXT,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(section,batch_hash,file_name)
    );
    CREATE TABLE IF NOT EXISTS tse_decodes (
      section INTEGER NOT NULL,
      batch_hash TEXT NOT NULL,
      file_name TEXT NOT NULL,
      artifact_sha256 TEXT,
      decode_status TEXT NOT NULL,
      detected_format TEXT,
      decoder_version TEXT,
      parsed_json TEXT,
      last_error TEXT,
      decoded_at TEXT,
      updated_at TEXT NOT NULL,
      PRIMARY KEY(section,batch_hash,file_name)
    );
    CREATE INDEX IF NOT EXISTS idx_tse_artifacts_section_class ON tse_artifacts(section,file_class,download_status);
    CREATE INDEX IF NOT EXISTS idx_tse_decodes_section_status ON tse_decodes(section,decode_status);
  `);
  const upsert = db.prepare(`INSERT INTO tse_sections(section,principal_section,aggregated_json,ea16_available,aux_date,aux_time,tse_status,hash_count,last_hash_status,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(section) DO UPDATE SET
      principal_section=excluded.principal_section,
      aggregated_json=excluded.aggregated_json,
      ea16_available=excluded.ea16_available,
      aux_date=excluded.aux_date,
      aux_time=excluded.aux_time,
      tse_status=excluded.tse_status,
      hash_count=excluded.hash_count,
      last_hash_status=excluded.last_hash_status,
      updated_at=excluded.updated_at`);
  const listDb = db.prepare('SELECT * FROM tse_sections ORDER BY section');
  const getArtifactDb = db.prepare('SELECT * FROM tse_artifacts WHERE section=? AND batch_hash=? AND file_name=?');
  const upsertArtifactDb = db.prepare(`INSERT INTO tse_artifacts(section,batch_hash,received_date,received_time,batch_status,file_name,file_type,file_class,file_url,download_status,local_path,size_bytes,sha256,sha512,downloaded_at,last_error,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(section,batch_hash,file_name) DO UPDATE SET
      received_date=excluded.received_date,
      received_time=excluded.received_time,
      batch_status=excluded.batch_status,
      file_type=excluded.file_type,
      file_class=excluded.file_class,
      file_url=excluded.file_url,
      download_status=CASE WHEN tse_artifacts.download_status='downloaded' THEN tse_artifacts.download_status ELSE excluded.download_status END,
      local_path=CASE WHEN tse_artifacts.download_status='downloaded' THEN tse_artifacts.local_path ELSE excluded.local_path END,
      size_bytes=CASE WHEN tse_artifacts.download_status='downloaded' THEN tse_artifacts.size_bytes ELSE excluded.size_bytes END,
      sha256=CASE WHEN tse_artifacts.download_status='downloaded' THEN tse_artifacts.sha256 ELSE excluded.sha256 END,
      sha512=CASE WHEN tse_artifacts.download_status='downloaded' THEN tse_artifacts.sha512 ELSE excluded.sha512 END,
      downloaded_at=CASE WHEN tse_artifacts.download_status='downloaded' THEN tse_artifacts.downloaded_at ELSE excluded.downloaded_at END,
      last_error=CASE WHEN tse_artifacts.download_status='downloaded' THEN NULL ELSE excluded.last_error END,
      updated_at=excluded.updated_at`);
  const markArtifactDownloadedDb = db.prepare(`UPDATE tse_artifacts SET download_status='downloaded',local_path=?,size_bytes=?,sha256=?,sha512=?,downloaded_at=?,last_error=NULL,updated_at=? WHERE section=? AND batch_hash=? AND file_name=?`);
  const markArtifactErrorDb = db.prepare(`UPDATE tse_artifacts SET download_status=?,last_error=?,updated_at=? WHERE section=? AND batch_hash=? AND file_name=?`);
  const listArtifactsDb = db.prepare('SELECT * FROM tse_artifacts WHERE section=? ORDER BY received_date DESC, received_time DESC, rowid DESC');
  const getDecodeDb = db.prepare('SELECT * FROM tse_decodes WHERE section=? AND batch_hash=? AND file_name=?');
  const upsertDecodeDb = db.prepare(`INSERT INTO tse_decodes(section,batch_hash,file_name,artifact_sha256,decode_status,detected_format,decoder_version,parsed_json,last_error,decoded_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(section,batch_hash,file_name) DO UPDATE SET artifact_sha256=excluded.artifact_sha256,decode_status=excluded.decode_status,detected_format=excluded.detected_format,decoder_version=excluded.decoder_version,parsed_json=excluded.parsed_json,last_error=excluded.last_error,decoded_at=excluded.decoded_at,updated_at=excluded.updated_at`);
  const listDecodesDb = db.prepare('SELECT * FROM tse_decodes WHERE section=? ORDER BY decoded_at DESC, rowid DESC');
  const artifactSummaryDb = db.prepare(`SELECT a.section,
    MAX(CASE WHEN a.file_class='BU' THEN 1 ELSE 0 END) AS bu_listed,
    MAX(CASE WHEN a.file_class='BU' AND a.download_status='downloaded' THEN 1 ELSE 0 END) AS bu_downloaded,
    MAX(CASE WHEN a.file_class='IMGBU' AND a.download_status='downloaded' THEN 1 ELSE 0 END) AS imgbu_downloaded,
    MAX(CASE WHEN a.file_class='VOTA' AND a.download_status='downloaded' THEN 1 ELSE 0 END) AS vota_downloaded,
    MAX(CASE WHEN a.file_class='SIGNATURE' AND a.download_status='downloaded' THEN 1 ELSE 0 END) AS signature_downloaded,
    MAX(CASE WHEN d.decode_status='decoded' THEN 1 ELSE 0 END) AS structured_ready,
    MAX(CASE WHEN d.decode_status='unsupported_binary' THEN 1 ELSE 0 END) AS unsupported_binary
    FROM tse_artifacts a LEFT JOIN tse_decodes d ON d.section=a.section AND d.batch_hash=a.batch_hash AND d.file_name=a.file_name GROUP BY a.section`);

  const state = {
    source: 'TSE · Divulgação de Resultados 2026',
    baseUrl: base,
    ambiente: env,
    phase: 'initializing',
    message: 'Preparando integração com a divulgação oficial do TSE.',
    lastAttempt: null,
    lastSuccess: null,
    lastError: null,
    cycle: null,
    pleitoCode: null,
    electionCodes: [],
    municipalityCode: null,
    municipalityName: 'Colméia',
    zone: TARGET_ZONE,
    sectionsExpected: localSections.length,
    ea16Url: null,
    artifactMode: 'EA18 exact-file discovery + guarded download',
    comparisonMode: 'safe_auto_compare_when_structured_official_payload_is_decodable',
    summary: {known:0, auxiliaryReady:0, received:0, totalized:0, officialBuListed:0, officialBuDownloaded:0, officialImageBuDownloaded:0, officialVotaDownloaded:0, structuredOfficialReady:0, signaturesDownloaded:0},
  };

  function artifactSummaryMap() {
    const map = new Map();
    for (const r of artifactSummaryDb.all()) map.set(Number(r.section), {
      officialBuListed: !!r.bu_listed,
      officialBuDownloaded: !!r.bu_downloaded,
      officialImageBuDownloaded: !!r.imgbu_downloaded,
      officialVotaDownloaded: !!r.vota_downloaded,
      structuredOfficialReady: !!r.structured_ready,
      unsupportedBinary: !!r.unsupported_binary,
      signatureDownloaded: !!r.signature_downloaded,
    });
    return map;
  }

  function publicSections() {
    const evidence = artifactSummaryMap();
    const out = {};
    for (const r of listDb.all()) {
      const ev = evidence.get(Number(r.section)) || {};
      out[String(r.section)] = {
        section: r.section,
        principalSection: r.principal_section,
        aggregated: JSON.parse(r.aggregated_json || '[]'),
        tseFileAvailable: !!r.ea16_available,
        auxiliaryDate: r.aux_date || null,
        auxiliaryTime: r.aux_time || null,
        tseStatus: r.tse_status || null,
        hashCount: Number(r.hash_count || 0),
        lastHashStatus: r.last_hash_status || null,
        officialBuListed: !!ev.officialBuListed,
        officialBuDownloaded: !!ev.officialBuDownloaded,
        officialImageBuDownloaded: !!ev.officialImageBuDownloaded,
        officialVotaDownloaded: !!ev.officialVotaDownloaded,
        structuredOfficialReady: !!ev.structuredOfficialReady,
        decoderStatus: ev.structuredOfficialReady ? 'decoded' : (ev.unsupportedBinary ? 'awaiting_2026_binary_spec' : 'waiting_artifact'),
        signatureDownloaded: !!ev.signatureDownloaded,
        updatedAt: r.updated_at,
      };
    }
    return out;
  }

  function publicArtifact(row) {
    return {
      section: Number(row.section),
      batchHash: row.batch_hash,
      receivedDate: row.received_date || null,
      receivedTime: row.received_time || null,
      batchStatus: row.batch_status || null,
      fileName: row.file_name,
      fileType: row.file_type || null,
      fileClass: row.file_class,
      url: row.file_url,
      downloadStatus: row.download_status,
      sizeBytes: row.size_bytes == null ? null : Number(row.size_bytes),
      sha256: row.sha256 || null,
      sha512: row.sha512 || null,
      downloadedAt: row.downloaded_at || null,
      lastError: row.download_status === 'downloaded' ? null : (row.last_error || null),
      decode: (()=>{const d=getDecodeDb.get(Number(row.section),row.batch_hash,row.file_name);return d?{status:d.decode_status,format:d.detected_format||null,decoderVersion:d.decoder_version||null,decodedAt:d.decoded_at||null,error:d.last_error||null}:null})(),
      updatedAt: row.updated_at,
    };
  }

  function getSectionEvidence(section) {
    const sec = Number(section);
    if (!localSections.includes(sec)) return null;
    const sectionState = publicSections()[String(sec)] || {section:sec};
    const artifacts = listArtifactsDb.all(sec).map(publicArtifact);
    const officialBu = artifacts.filter(a=>a.fileClass==='BU');
    const officialImageBu = artifacts.filter(a=>a.fileClass==='IMGBU');
    const officialVota = artifacts.filter(a=>a.fileClass==='VOTA');
    const signatures = artifacts.filter(a=>a.fileClass==='SIGNATURE');
    const decodes = listDecodesDb.all(sec).map(d=>({fileName:d.file_name,batchHash:d.batch_hash,status:d.decode_status,format:d.detected_format||null,decoderVersion:d.decoder_version||null,artifactSha256:d.artifact_sha256||null,decodedAt:d.decoded_at||null,error:d.last_error||null}));
    const structuredReady=decodes.some(d=>d.status==='decoded');
    return {
      section: sec, sectionState, officialBu, officialImageBu, officialVota, signatures, artifacts, decodes,
      officialBuReady: officialBu.some(a=>a.downloadStatus==='downloaded'),
      officialImageBuReady: officialImageBu.some(a=>a.downloadStatus==='downloaded'),
      officialVotaReady: officialVota.some(a=>a.downloadStatus==='downloaded'),
      signatureReady: signatures.some(a=>a.downloadStatus==='downloaded'),
      structuredOfficialReady: structuredReady,
      voteComparison: structuredReady ? 'structured_official_ready' : (decodes.some(d=>d.status==='unsupported_binary') ? 'awaiting_2026_binary_spec' : 'waiting_official_artifact'),
      note: structuredReady ? 'Dados estruturados do artefato oficial foram decodificados com um adaptador seguro e enviados ao motor de conferência.' : 'O arquivo oficial é preservado e identificado. Formatos binários não são interpretados sem especificação 2026 confirmada; o sistema não declara conferência por aproximação.',
    };
  }

  function getStatus() {
    return {...state, sections: publicSections()};
  }

  async function fetchJson(url, {allow404=false}={}) {
    const prev = cache.get(url);
    const headers = {'accept':'application/json'};
    if (prev?.etag) headers['if-none-match'] = prev.etag;
    if (prev?.lastModified) headers['if-modified-since'] = prev.lastModified;
    let res;
    try {
      res = await fetch(url, {headers, signal: AbortSignal.timeout(12000)});
    } catch (e) {
      throw new Error(`tse_network:${e?.name || 'error'}`);
    }
    if (res.status === 304 && prev?.json) return prev.json;
    if (res.status === 404 && allow404) return null;
    if (!res.ok) throw new Error(`tse_http_${res.status}`);
    const json = await res.json();
    cache.set(url, {json, etag:res.headers.get('etag'), lastModified:res.headers.get('last-modified')});
    return json;
  }

  async function fetchArtifact(url) {
    let res;
    try {
      res = await fetch(url, {headers:{'accept':'application/octet-stream,*/*;q=0.8'}, signal:AbortSignal.timeout(20000)});
    } catch (e) {
      throw new Error(`tse_artifact_network:${e?.name || 'error'}`);
    }
    if (res.status === 404) return {notFound:true};
    if (!res.ok) throw new Error(`tse_artifact_http_${res.status}`);
    const declared = Number(res.headers.get('content-length') || 0);
    if (declared && declared > maxArtifactBytes) throw new Error('tse_artifact_too_large');
    const data = Buffer.from(await res.arrayBuffer());
    if (data.length > maxArtifactBytes) throw new Error('tse_artifact_too_large');
    return {data};
  }

  function find2026Pleito(cfg) {
    const pleitos = Array.isArray(cfg?.pl) ? cfg.pl : [];
    return pleitos.find(p => String(p.dt || '') === TARGET_DATE) || null;
  }

  function electionDescriptors(pleito) {
    return (Array.isArray(pleito?.e) ? pleito.e : []).map(e => ({
      code: String(e.cd || ''),
      turn: String(e.t || ''),
      name: String(e.nm || '').replace(/&[^;]+;/g, ' '),
      cargos: (Array.isArray(e.abr) ? e.abr : []).flatMap(a => Array.isArray(a.cp) ? a.cp.map(c => Number(c.cd)) : []),
    }));
  }

  function templateDir(cfg, tp, vars) {
    const item = (Array.isArray(cfg?.arq) ? cfg.arq : []).find(x => x.tp === tp);
    if (!item?.dir) return null;
    const replacements = {
      '<base>': base,
      '<ambiente>': env,
      '<ciclo>': vars.cycle,
      '<cd_eleicao>': vars.electionCode || '',
      '<cd_pleito>': vars.pleitoCode || '',
      '<uf>': vars.uf || TARGET_UF,
    };
    let dir = item.dir;
    for (const [token, value] of Object.entries(replacements)) dir = dir.split(token).join(String(value));
    return dir.replace(/\/+$/, '');
  }

  function ea18Url({cycle, pleitoCode, municipalityCode, section}) {
    const p6 = pad(pleitoCode, 6), m5 = pad(municipalityCode, 5), z4 = pad(TARGET_ZONE, 4), s4 = pad(section, 4);
    return `${base}/${env}/${cycle}/arquivo-urna/${pleitoCode}/dados/${TARGET_UF}/${m5}/${z4}/${s4}/p${p6}-${TARGET_UF}-m${m5}-z${z4}-s${s4}-aux.json`;
  }

  function persistSection(section, record, aux) {
    const aggregated = Array.isArray(record?.nsa) ? record.nsa.map(x=>Number(x)).filter(Number.isInteger) : [];
    const batches = normalizeEa18(aux);
    const latest = batches[batches.length - 1] || null;
    upsert.run(
      Number(section), Number(section), JSON.stringify(aggregated), record?.da && record?.ha ? 1 : 0,
      record?.da || null, record?.ha || null, aux?.st || null, batches.length,
      latest?.status || null, nowIso()
    );
  }

  function persistArtifactMetadata({section, cycle, pleitoCode, municipalityCode, aux}) {
    const batches = normalizeEa18(aux);
    for (const batch of batches) {
      for (const file of batch.files) {
        const url = artifactUrl({base,env,cycle,pleitoCode,municipalityCode,section,batchHash:batch.hash,fileName:file.name});
        if (!url) continue;
        const before = getArtifactDb.get(Number(section), batch.hash, file.name);
        upsertArtifactDb.run(
          Number(section), batch.hash, batch.receivedDate || null, batch.receivedTime || null, batch.status || null,
          file.name, file.type || null, file.class, url,
          before?.download_status === 'downloaded' ? 'downloaded' : 'listed',
          before?.local_path || null, before?.size_bytes ?? null, before?.sha256 || null, before?.sha512 || null,
          before?.downloaded_at || null, before?.download_status === 'downloaded' ? null : before?.last_error || null, nowIso()
        );
      }
    }
    return batches;
  }

  async function tryDecodeOfficial(row, data, sha256) {
    if (!row || !['BU','VOTA'].includes(row.file_class)) return null;
    const previous=getDecodeDb.get(Number(row.section),row.batch_hash,row.file_name);
    if(previous?.artifact_sha256===sha256 && previous?.decode_status==='decoded') return previous;
    const decoded=decodeOfficialArtifact({data,fileName:row.file_name});
    const at=nowIso();
    upsertDecodeDb.run(Number(row.section),row.batch_hash,row.file_name,sha256,decoded.status,decoded.format||null,decoded.decoderVersion||DECODER_VERSION,decoded.ok?JSON.stringify(decoded.parsed):null,decoded.ok?null:(decoded.reason||'decode_failed'),decoded.ok?at:null,at);
    if(decoded.ok && typeof onOfficialDecoded==='function') {
      try { await onOfficialDecoded({section:Number(row.section),artifact:{fileName:row.file_name,batchHash:row.batch_hash,sha256,decoderVersion:decoded.decoderVersion,format:decoded.format},parsed:decoded.parsed}); }
      catch(e){ console.warn('[TSE comparação]',row.section,row.file_name,String(e?.message||e).slice(0,180)); }
    }
    return decoded;
  }

  async function ensureDecodeForDownloaded(row) {
    if(!row || !['BU','VOTA'].includes(row.file_class) || row.download_status!=='downloaded' || !row.local_path || !existsSync(row.local_path)) return;
    const previous=getDecodeDb.get(Number(row.section),row.batch_hash,row.file_name);
    if(previous?.artifact_sha256===row.sha256 && previous?.decode_status==='decoded') return;
    try { const data=await readFile(row.local_path); await tryDecodeOfficial(row,data,row.sha256||crypto.createHash('sha256').update(data).digest('hex')); } catch(e) { console.warn('[TSE decoder]',row.section,row.file_name,String(e?.message||e).slice(0,160)); }
  }

  async function downloadOneArtifact(row) {
    if (!row || !['BU','IMGBU','VOTA','SIGNATURE'].includes(row.file_class)) return false;
    if (row.download_status === 'downloaded' && row.local_path && existsSync(row.local_path)) { await ensureDecodeForDownloaded(row); return true; }
    const safeName = sanitizeArtifactName(row.file_name);
    const safeHash = String(row.batch_hash || '');
    if (!safeName || !/^[A-Za-z0-9_-]{8,256}$/.test(safeHash)) return false;
    const dir = path.join(artifactRoot, pad(row.section,4), safeHash);
    const finalPath = path.join(dir, safeName);
    try {
      const fetched = await fetchArtifact(row.file_url);
      if (fetched.notFound) {
        markArtifactErrorDb.run('listed','arquivo_listado_ainda_indisponivel_no_cdn',nowIso(),row.section,row.batch_hash,row.file_name);
        return false;
      }
      await mkdir(dir, {recursive:true});
      const tmp = `${finalPath}.tmp-${process.pid}-${Date.now()}`;
      await writeFile(tmp, fetched.data, {mode:0o600});
      await rename(tmp, finalPath);
      const sha256 = crypto.createHash('sha256').update(fetched.data).digest('hex');
      const sha512 = crypto.createHash('sha512').update(fetched.data).digest('hex');
      const at = nowIso();
      markArtifactDownloadedDb.run(finalPath,fetched.data.length,sha256,sha512,at,at,row.section,row.batch_hash,row.file_name);
      await tryDecodeOfficial({...row,download_status:'downloaded',local_path:finalPath,sha256},fetched.data,sha256);
      return true;
    } catch (e) {
      const msg = String(e?.message || e).slice(0,180);
      markArtifactErrorDb.run('error',msg,nowIso(),row.section,row.batch_hash,row.file_name);
      console.warn('[TSE artefato]', row.section, row.file_class, row.file_name, msg);
      return false;
    }
  }

  async function downloadListedOfficialArtifacts(section) {
    const rows = listArtifactsDb.all(Number(section));
    const targets = rows.filter(r => ['BU','IMGBU','VOTA','SIGNATURE'].includes(r.file_class));
    for (const row of targets) await downloadOneArtifact(row);
  }

  function updateSummary() {
    const rows = listDb.all();
    const ev = artifactSummaryMap();
    state.summary = {
      known: rows.filter(r=>localSections.includes(Number(r.section))).length,
      auxiliaryReady: rows.filter(r=>r.ea16_available).length,
      received: rows.filter(r=>Number(r.hash_count)>0).length,
      totalized: rows.filter(r=>norm(r.tse_status).includes('totalizada') || norm(r.last_hash_status).includes('totalizado')).length,
      officialBuListed: localSections.filter(s=>ev.get(s)?.officialBuListed).length,
      officialBuDownloaded: localSections.filter(s=>ev.get(s)?.officialBuDownloaded).length,
      officialImageBuDownloaded: localSections.filter(s=>ev.get(s)?.officialImageBuDownloaded).length,
      officialVotaDownloaded: localSections.filter(s=>ev.get(s)?.officialVotaDownloaded).length,
      structuredOfficialReady: localSections.filter(s=>ev.get(s)?.structuredOfficialReady).length,
      signaturesDownloaded: localSections.filter(s=>ev.get(s)?.signatureDownloaded).length,
    };
  }

  async function refresh({manual=false}={}) {
    if (running) return getStatus();
    running = true;
    state.lastAttempt = nowIso();
    state.lastError = null;
    try {
      const cfgUrl = `${base}/${env}/comum/config/ele-c.json`;
      const cfg = await fetchJson(cfgUrl);
      const pleito = find2026Pleito(cfg);
      if (!pleito) {
        state.phase = 'waiting_2026_config';
        state.cycle = cfg?.c || null;
        state.pleitoCode = null;
        state.electionCodes = [];
        state.message = 'Conector pronto. O arquivo EA11 público ainda não contém o pleito de 4/10/2026.';
        updateSummary();
        return getStatus();
      }

      const cycle = String(cfg.c || 'ele2026');
      const pleitoCode = String(pleito.cd || '');
      const elections = electionDescriptors(pleito);
      state.cycle = cycle;
      state.pleitoCode = pleitoCode;
      state.electionCodes = elections;

      const csDir = templateDir(cfg, 'cs', {cycle, pleitoCode, uf:TARGET_UF});
      if (!csDir) throw new Error('tse_ea11_missing_cs_template');
      const ea16UrlValue = `${csDir}/${TARGET_UF}-p${pad(pleitoCode,6)}-cs.json`;
      state.ea16Url = ea16UrlValue;
      const ea16 = await fetchJson(ea16UrlValue, {allow404:true});
      if (!ea16) {
        state.phase = 'waiting_ea16';
        state.message = 'Pleito 2026 identificado; aguardando o arquivo EA16 de seções do Tocantins.';
        updateSummary();
        return getStatus();
      }

      const abr = (ea16.abr || []).find(a => norm(a.cd) === TARGET_UF);
      const mu = (abr?.mu || []).find(m => norm(m.nm) === TARGET_CITY);
      if (!mu) throw new Error('tse_colmeia_not_found_in_ea16');
      state.municipalityCode = pad(mu.cd,5);
      const zone = (mu.zon || []).find(z => pad(z.cd,4) === TARGET_ZONE);
      if (!zone) throw new Error('tse_zone_0016_not_found');
      const bySection = new Map((zone.sec || []).map(s => [Number(s.ns), s]));

      let found = 0;
      for (const section of localSections) {
        const rec = bySection.get(section);
        if (!rec) continue;
        found++;
        let aux = null;
        if (rec.da && rec.ha) {
          const url = ea18Url({cycle, pleitoCode, municipalityCode:mu.cd, section});
          try { aux = await fetchJson(url, {allow404:true}); }
          catch (e) { console.warn('EA18 indisponível', section, e.message); }
        }
        persistSection(section, rec, aux);
        if (aux) {
          persistArtifactMetadata({section,cycle,pleitoCode,municipalityCode:mu.cd,aux});
          await downloadListedOfficialArtifacts(section);
        }
      }

      updateSummary();
      state.phase = found === localSections.length ? 'ready' : 'partial_sections';
      state.lastSuccess = nowIso();
      state.message = found === localSections.length
        ? `EA16/EA18 sincronizados para Colméia/16ª ZE. ${state.summary.received}/${localSections.length} seções têm arquivos de urna; ${state.summary.officialBuDownloaded}/${localSections.length} já têm BU oficial preservado pela central.`
        : `EA16 carregado, mas ${localSections.length-found} seção(ões) local(is) ainda não foram encontradas na configuração oficial.`;
      broadcast?.('tse_update', {phase:state.phase, summary:state.summary, updatedAt:state.lastSuccess});
      return getStatus();
    } catch (e) {
      state.phase = 'error';
      state.lastError = String(e?.message || e);
      state.message = 'Não foi possível atualizar a integração do TSE agora. A central local continua funcionando normalmente.';
      console.warn('[TSE sync]', e);
      return getStatus();
    } finally {
      running = false;
      if (!manual) schedule();
    }
  }

  function schedule() {
    if (stopped) return;
    clearTimeout(timer);
    const seconds = state.phase === 'waiting_2026_config' ? Math.max(300, configuredPoll) : configuredPoll;
    timer = setTimeout(() => refresh(), seconds * 1000);
    timer.unref?.();
  }

  function start() {
    setTimeout(()=>refresh(), 1200).unref?.();
  }
  function stop() { stopped = true; clearTimeout(timer); }

  return {getStatus, getSectionEvidence, refresh, start, stop};
}
