# Integração TSE — V0.18

A V0.18 amplia o conector oficial da Central Eleitoral de Colméia para localizar, preservar e — quando o conteúdo puder ser reconhecido com segurança — decodificar o artefato oficial e comparar automaticamente seu conteúdo com o BU recebido localmente. Os dois lados permanecem armazenados separadamente.

## Fluxo implementado

1. Consulta `/<ambiente>/comum/config/ele-c.json` (EA11).
2. Procura o pleito do primeiro turno em `04/10/2026`.
3. Descobre ciclo, código do pleito e códigos das eleições sem fixá-los manualmente.
4. Monta a URL do EA16 usando o template publicado no próprio EA11.
5. No EA16, localiza TO -> Colméia -> 16ª Zona Eleitoral.
6. Acompanha as 29 seções receptoras da base local.
7. Só tenta EA18 quando o EA16 informa `da` e `ha`.
8. Lê do EA18 os hashes e os nomes exatos dos arquivos de urna; não adivinha nomes de arquivos.
9. Registra em SQLite os metadados de todos os artefatos listados no EA18.
10. Baixa automaticamente os arquivos classificados como BU, IMGBU, VOTA e assinatura que sejam relevantes ao fluxo de evidência, com limite de tamanho e proteção contra path traversal.
11. Preserva os bytes no volume persistente e calcula SHA-256 e SHA-512 para trilha de integridade local.
12. Para BU/VOTA, executa o decoder seguro da V0.18.
13. Se o conteúdo for QRBU textual ou JSON estruturado reconhecido, cria o payload oficial por cargo e dispara a comparação automática.
14. Se o conteúdo for binário não reconhecido, registra `awaiting_2026_binary_spec` e não tenta inferir votos.

Os artefatos são gravados em:

`<DATA_DIR>/tse/artifacts/<seção>/<hash>/<arquivo>`

Na Railway, `DATA_DIR` é substituído pelo volume detectado em `RAILWAY_VOLUME_MOUNT_PATH`, atualmente montado em `/data`.

## Regra de segurança da conferência

A V0.18 distingue explicitamente três etapas:

1. **Artefato oficial preservado** — o arquivo indicado pelo EA18 foi baixado e recebeu hashes locais.
2. **Oficial estruturado** — o conteúdo foi reconhecido por um decoder seguro (QRBU textual ou JSON estruturado).
3. **Conferido** — há payload local e oficial para o mesmo cargo e o motor comparou os campos relevantes sem encontrar diferença.

Somente a terceira etapa gera `verified`. Se houver qualquer diferença em candidato, legenda, brancos, nulos, comparecimento ou total de válidos, o status é `divergent`; nenhum lado é sobrescrito.

O arquivo `.bu` binário que não puder ser interpretado com segurança fica preservado e recebe o estado `awaiting_2026_binary_spec`. A V0.18 **não assume** que uma especificação binária de eleição anterior permaneça idêntica em 2026.

Também não se presume que o `HASH` impresso no QR seja igual ao hash de pasta do EA18 ou ao SHA calculado do arquivo; cada identificador é mantido no seu contexto.

## Endpoints

- `GET /api/tse/status` — estado público do conector, incluindo EA18, artefatos baixados e quantidade de seções com oficial estruturado.
- `GET /api/tse/section?section=49` — evidência oficial, artefatos e estado do decoder de uma seção, sem expor caminho local do servidor.
- `GET /api/tse/comparison?section=49` — comparação por cargo, incluindo diferenças estruturadas quando houver.
- `POST /api/tse/refresh` — atualização manual, restrita à coordenação.

## Configuração opcional

- `TSE_BASE_URL` (padrão: `https://resultados.tse.jus.br`)
- `TSE_AMBIENTE` (padrão: `oficial`)
- `TSE_POLL_SECONDS` (padrão: `60`, mínimo: `30`)
- `TSE_MAX_ARTIFACT_BYTES` (padrão: `26214400`, 25 MiB)

Enquanto o EA11 ainda não contiver o pleito de 2026, o conector permanece em `waiting_2026_config` e não constrói URLs especulativas para EA16/EA18 ou arquivos de urna.
