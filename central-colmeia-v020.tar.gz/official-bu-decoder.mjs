export const DECODER_VERSION = 'v0.18-safe-text-qrbu-json-1';
const CARGO_MAP={1:'presidente',3:'governador',5:'senador',6:'depFederal',7:'depEstadual'};
const CARGO_NAMES={1:'Presidente',3:'Governador',5:'Senador',6:'Deputado Federal',7:'Deputado Estadual'};
const GLOBAL_ANYWHERE=new Set(['HASH','ASSI']);
const NUMBER_FIELDS=new Set(['SECA','ZONA','MUNI','COMP','APTO','FALT','LOCA','TURN','PLEI','IDEL','IDUE','HBMA']);
const asNumber=v=>{const n=Number(v);return Number.isFinite(n)?n:0};
function splitToken(token){const p=String(token||'').indexOf(':');return p<0?[String(token||''),'']:[token.slice(0,p),token.slice(p+1)]}

export function parseQrBuText(raw){
  const text=String(raw||'').replace(/[\r\n\t]+/g,' ').replace(/\s+/g,' ').trim();
  if(!/^QRBU:\d+:\d+(?:\s|$)/i.test(text))throw new Error('not_qrbu');
  const hm=text.match(/^QRBU:(\d+):(\d+)/i); const meta={qrTotal:Number(hm?.[2]||1)};
  const tokens=text.split(' '); const cargos=[]; let current=null,currentParty=null;
  function finish(){
    if(!current)return;
    const byNum=new Map(); for(const c of current.candidatos){const k=String(c.numero);byNum.set(k,{numero:k,votos:(byNum.get(k)?.votos||0)+asNumber(c.votos)})}
    current.candidatos=[...byNum.values()].sort((a,b)=>a.numero.localeCompare(b.numero,'pt-BR',{numeric:true}));
    const leg=new Map(); for(const l of current.legendas){const k=String(l.numero);leg.set(k,{numero:k,votos:(leg.get(k)?.votos||0)+asNumber(l.votos)})}
    current.legendas=[...leg.values()].sort((a,b)=>a.numero.localeCompare(b.numero,'pt-BR',{numeric:true}));
    current.cargo=CARGO_MAP[current.codigo]||null; current.nome=CARGO_NAMES[current.codigo]||`Cargo ${current.codigo}`; cargos.push(current); current=null; currentParty=null;
  }
  for(let i=1;i<tokens.length;i++){
    const [keyRaw,valueRaw]=splitToken(tokens[i]); const key=keyRaw.toUpperCase(),value=valueRaw;
    if(key==='QRBU')continue;
    if(key==='CARG'){finish();current={codigo:asNumber(value),cargo:null,nome:'',tipo:null,candidatos:[],legendas:[],brancos:0,nulos:0,total:0,nominais:0,votosLegenda:0,fields:{}};continue}
    if(GLOBAL_ANYWHERE.has(key)){meta[key]=value;continue}
    if(!current){meta[key]=NUMBER_FIELDS.has(key)?asNumber(value):value;continue}
    if(key==='PART'){currentParty=String(value);continue}
    if(key==='LEGP'){const votos=asNumber(value);current.votosLegenda+=votos;if(currentParty)current.legendas.push({numero:currentParty,votos});continue}
    if(key==='TIPO'){current.tipo=asNumber(value);continue}
    if(key==='BRAN'){current.brancos=asNumber(value);continue}
    if(key==='NULO'){current.nulos=asNumber(value);continue}
    if(key==='TOTC'){current.total=asNumber(value);continue}
    if(key==='NOMI'){current.nominais=asNumber(value);continue}
    if(key==='LEGC'){current.votosLegenda=asNumber(value);continue}
    if(/^\d+$/.test(key)){current.candidatos.push({numero:key,votos:asNumber(value)});continue}
    current.fields[key]=value;
  }
  finish();
  return {raw:text,meta,cargos,recognizedCargos:cargos.filter(c=>c.cargo)};
}

function looksText(data){
  const sample=data.subarray(0,Math.min(data.length,8192)); if(!sample.length)return false;
  let printable=0, bad=0;
  for(const b of sample){if(b===0)bad+=4; else if(b===9||b===10||b===13||(b>=32&&b<=126)||b>=0xC2)printable++; else bad++;}
  return printable/(printable+bad) > 0.88;
}
function normalizeStructured(obj){
  if(!obj||typeof obj!=='object')return null;
  if(typeof obj.raw==='string'&&obj.raw.trim().startsWith('QRBU:'))return parseQrBuText(obj.raw);
  const cargos=Array.isArray(obj.recognizedCargos)?obj.recognizedCargos:(Array.isArray(obj.cargos)?obj.cargos:null);
  if(!cargos)return null;
  const normalized=cargos.map(c=>({
    codigo:asNumber(c.codigo), cargo:c.cargo||CARGO_MAP[asNumber(c.codigo)]||null, nome:c.nome||'', tipo:c.tipo??null,
    candidatos:Array.isArray(c.candidatos)?c.candidatos.map(x=>({numero:String(x.numero||''),votos:asNumber(x.votos)})):[],
    legendas:Array.isArray(c.legendas)?c.legendas.map(x=>({numero:String(x.numero||''),votos:asNumber(x.votos)})):[],
    brancos:asNumber(c.brancos), nulos:asNumber(c.nulos), total:asNumber(c.total), nominais:asNumber(c.nominais), votosLegenda:asNumber(c.votosLegenda), fields:c.fields||{}
  })).filter(c=>c.cargo);
  if(!normalized.length)return null;
  return {raw:null,meta:obj.meta&&typeof obj.meta==='object'?obj.meta:{},cargos:normalized,recognizedCargos:normalized};
}

export function decodeOfficialArtifact({data,fileName=''}){
  const buffer=Buffer.isBuffer(data)?data:Buffer.from(data||[]);
  const lower=String(fileName||'').toLowerCase();
  if(!buffer.length)return {ok:false,status:'empty',format:'empty',decoderVersion:DECODER_VERSION,reason:'arquivo_vazio'};
  if(!looksText(buffer))return {ok:false,status:'unsupported_binary',format:lower.endsWith('.bu')?'tse_bu_binary':'binary',decoderVersion:DECODER_VERSION,reason:'formato_binario_2026_sem_especificacao_publicada_confirmada'};
  let text=buffer.toString('utf8').replace(/^\uFEFF/,'').trim();
  const q=text.indexOf('QRBU:'); if(q>0) text=text.slice(q).trim();
  try{
    if(text.startsWith('QRBU:'))return {ok:true,status:'decoded',format:'qrbu_text',decoderVersion:DECODER_VERSION,parsed:parseQrBuText(text)};
    if(text.startsWith('{')||text.startsWith('[')){
      const obj=JSON.parse(text); const parsed=normalizeStructured(obj);
      if(parsed)return {ok:true,status:'decoded',format:'structured_json',decoderVersion:DECODER_VERSION,parsed};
      return {ok:false,status:'unsupported_text',format:'json_unknown',decoderVersion:DECODER_VERSION,reason:'json_sem_estrutura_de_bu_reconhecida'};
    }
  }catch(e){return {ok:false,status:'decode_error',format:'text',decoderVersion:DECODER_VERSION,reason:String(e?.message||e).slice(0,160)}}
  return {ok:false,status:'unsupported_text',format:'text_unknown',decoderVersion:DECODER_VERSION,reason:'texto_sem_qrbu_ou_json_estruturado'};
}
