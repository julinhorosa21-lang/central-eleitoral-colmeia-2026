# Painel da Coordenação — V0.18

O painel administrativo continua protegido pela chave geral e acompanha as 29 seções receptoras.

Na V0.18, a coluna TSE diferencia EA18 recebido, artefato oficial preservado, binário aguardando especificação 2026 e oficial estruturado. A coluna de conferência só mostra cargo conferido quando o motor comparou efetivamente os payloads local e oficial.

O resumo inclui progresso dos BUs locais, quantidade de seções com oficial estruturado, cargos conferidos e divergências. A auditoria registra também a incorporação automática de payload oficial decodificado.

A coordenação pode forçar uma consulta ao TSE, exportar o relatório administrativo e usar `GET /api/tse/comparison?section=N` para inspecionar diferenças por cargo.
