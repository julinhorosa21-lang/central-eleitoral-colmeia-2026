import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const required=['server.mjs','public/index.html','public/data/locais-colmeia.json','public/data/candidatos-2026.json'];
let ok=true;
for(const f of required){const p=path.join(root,f);if(!existsSync(p)){console.error('FALTA:',f);ok=false}else console.log('OK:',f)}
const loc=JSON.parse(readFileSync(path.join(root,'public/data/locais-colmeia.json'),'utf8'));
const sections=loc.locais.flatMap(x=>x.secoes||[]);
console.log(`Locais: ${loc.locais.length} | Seções receptoras: ${sections.length}`);
if(loc.locais.length!==10) console.warn('ATENÇÃO: quantidade de locais diferente de 10.');
if(new Set(sections).size!==sections.length){console.error('ERRO: seção duplicada em mais de um local.');ok=false}
if(!ok) process.exit(1);
console.log('Pré-validação concluída.');
