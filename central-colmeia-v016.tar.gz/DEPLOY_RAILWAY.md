# Publicar a Central Eleitoral Colméia 2026 — V0.16 na Railway

Esta versão usa Node.js 22 + Dockerfile e mantém o banco/artefatos oficiais em armazenamento persistente.

## Configuração atual do projeto

- Healthcheck: `/api/health`
- Porta: usar `PORT` fornecida automaticamente pela Railway.
- Volume persistente: `/data`.
- O servidor detecta `RAILWAY_VOLUME_MOUNT_PATH` e grava nele:
  - `central.sqlite`;
  - `tse/artifacts/...` com BUs/assinaturas oficiais preservados.
- Em produção, as 29 chaves de seção + coordenação são comparadas por hashes SHA-256 incorporados ao servidor. As chaves em texto puro não devem ser publicadas.

## Variáveis opcionais do conector TSE

- `TSE_BASE_URL=https://resultados.tse.jus.br`
- `TSE_AMBIENTE=oficial`
- `TSE_POLL_SECONDS=60`
- `TSE_MAX_ARTIFACT_BYTES=26214400`

Os padrões já funcionam sem configurar essas variáveis.

## Verificação após deploy

1. Acessar `/api/health` e conferir `ok: true`, `version: 0.16.0` e `persistentStorage: true`.
2. Acessar `/api/tse/status` e conferir o estado do conector.
3. Acessar `/api/tse/section?section=49` para conferir a API de evidência por seção.
4. Validar que uma chave de operador continua limitada à sua própria seção.
5. Reiniciar/reimplantar o serviço e confirmar que o banco permanece no Volume.

## Segurança

- Nunca publicar `.env`, banco SQLite ou o PDF/arquivo com as chaves dos operadores.
- Não inferir nomes de arquivos de urna. A V0.16 usa somente os nomes e hashes fornecidos pelo EA18.
- A presença/download de um BU oficial não equivale a conferência voto a voto. O status `verified` só deve ser usado após decodificação e comparação do conteúdo oficial.
