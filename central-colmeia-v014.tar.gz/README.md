# Central Eleitoral Colméia 2026 — V0.14

Esta versão transforma o painel estático em uma central com servidor e banco de dados compartilhado.

## O que já funciona

- Banco SQLite central com uma linha por seção + cargo.
- API pública de leitura (`/api/snapshot`).
- Atualização em tempo real entre navegadores por Server-Sent Events (`/api/stream`).
- Operadores autenticados por chave.
- Permissão por seção receptora: cada operador possui uma chave limitada a uma única seção.
- Coordenação com acesso administrativo.
- Auditoria: criação, correção e exclusão ficam registradas.
- Dados locais de BU e dados oficiais do TSE são armazenados separadamente.
- Status: `local_pending`, `tse_official`, `verified` ou `divergent`.
- Se o servidor cair, o navegador pode guardar um envio na fila local e tentar sincronizar ao voltar.
- A interface V0.10 foi preservada: mapa, locais, candidatos, fotos e apuração por cargo.

## Rodar no computador

Requer Node.js 22 ou superior.

```bash
npm start
```

Abra:

`http://localhost:8787`

Em modo de desenvolvimento, se nenhuma chave for configurada, a chave administrativa é:

`COLMEIA-ADMIN-DEMO`

**Nunca use essa chave em produção.**

## Criar chaves reais dos operadores

```bash
npm run tokens
```

O comando gera:

- uma chave da coordenação;
- uma chave diferente para cada uma das 29 seções receptoras;
- um JSON para colocar em `OPERATOR_TOKENS`.

As chaves não devem ser colocadas dentro de `index.html`, GitHub público ou arquivos enviados ao público.

## Variáveis de ambiente

Veja `.env.example`.

- `PORT`
- `ADMIN_TOKEN`
- `OPERATOR_TOKENS`

## Banco

O arquivo é criado em:

`runtime/central.sqlite`

Em produção, essa pasta precisa estar em armazenamento persistente. Não use sistema de arquivos efêmero para o banco.

## Arquitetura

```
Público ────────┐
Operadores ─────┼──> servidor Node ──> SQLite
Coordenação ────┘         │
                          └── SSE -> atualização ao vivo

Futuro TSE/QR BU ─────────> mesma API -> conferência automática
```

## Próximas etapas

1. Publicar o servidor em hospedagem com disco persistente e HTTPS.
2. Gerar/distribuir as 29 chaves de operador, uma por seção receptora.
3. Implementar leitor do QR Code do Boletim de Urna.
4. Implementar importador EA16/EA18/EA20 do TSE.
5. Criar painel privado de auditoria e divergências.
6. Transformar em PWA instalável/offline.

## Observação

A Central é um projeto independente. Quando integrarmos os dados do TSE, o app deve diferenciar claramente resultados recebidos localmente por BU e resultados oficiais da Justiça Eleitoral.

## V0.12 — pronta para Railway

- Detecta automaticamente `RAILWAY_VOLUME_MOUNT_PATH` para persistir o SQLite.
- Servidor escuta em `0.0.0.0` e usa a variável `PORT` da hospedagem.
- `/api/health` informa se armazenamento persistente e autenticação estão configurados.
- Inclui `DEPLOY_RAILWAY.md`, `.dockerignore` e `npm run check`.


## V0.13 — leitura de QR do Boletim de Urna

- Leitura pela câmera do navegador em HTTPS.
- Captura automática de BUs com múltiplos QR Codes e remontagem por `QRBU:parte:total`.
- Interpretação estrutural dos cargos 1, 3, 5, 6 e 7 das eleições gerais.
- Preenchimento automático de candidatos, brancos, nulos e comparecimento.
- Votos de legenda preservados para cargos proporcionais.
- Botão para revisar um cargo ou salvar todos os cargos lidos.
- Fingerprint SHA-256 local do conteúdo remontado e metadados do BU gravados junto ao resultado.
- A V0.13 **não valida criptograficamente a assinatura do QR**; ela apenas registra a presença de HASH/ASSI. A validação por chaves públicas do TSE fica para etapa posterior.


## V0.14 — operadores por seção

- 29 chaves de operador, uma para cada seção receptora ativa de Colméia.
- A seção 49 usa uma única chave e representa também a seção agregada 113.
- 1 chave administrativa geral da coordenação, com acesso a todas as seções.
- O servidor rejeita gravações em seção diferente da autorizada pela chave.
- A interface mostra claramente a seção autorizada e trava o seletor para operadores de seção.
- Ao ler um QR de BU de outra seção, o app bloqueia o envio antes da publicação.
- O primeiro acesso da chave precisa ser validado online; depois, a identidade do operador pode ficar em cache no navegador para contingência.


## V0.14.1 — autenticação por hash
Em produção, as 29 chaves de seção e a chave administrativa são comparadas por SHA-256. As chaves em texto puro não ficam no repositório nem nas variáveis da Railway. As chaves entregues aos operadores permanecem as mesmas do arquivo confidencial gerado para V0.14.
