import http from 'node:http';
import { readFileSync, existsSync, mkdirSync } from 'node:fs';
import { stat, readFile } from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(__dirname, 'public');
const RUNTIME = process.env.DATA_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH || path.join(__dirname, 'runtime');
mkdirSync(RUNTIME, { recursive: true });
const PORT = Number(process.env.PORT || 8787);
const isProd = process.env.NODE_ENV === 'production';

const locations = JSON.parse(readFileSync(path.join(PUBLIC, 'data', 'locais-colmeia.json'), 'utf8'));
const sectionToPlace = new Map();
for (const place of locations.locais) for (const sec of place.secoes) sectionToPlace.set(Number(sec), place.id);
const allowedCargos = new Set(['presidente','governador','senador','depFederal','depEstadual']);

const db = new DatabaseSync(path.join(RUNTIME, 'central.sqlite'));
db.exec(`
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS results (
  section INTEGER NOT NULL,
  cargo TEXT NOT NULL,
  place_id TEXT NOT NULL,
  local_payload_json TEXT,
  official_payload_json TEXT,
  public_payload_json TEXT NOT NULL,
  verification_status TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY(section, cargo)
);
CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  action TEXT NOT NULL,
  section INTEGER,
  cargo TEXT,
  place_id TEXT,
  actor TEXT NOT NULL,
  before_json TEXT,
  after_json TEXT,
  created_at TEXT NOT NULL
);
`);

const getRow = db.prepare('SELECT * FROM results WHERE section=? AND cargo=?');
const listRows = db.prepare('SELECT * FROM results ORDER BY section, cargo');
const insertRow = db.prepare(`INSERT INTO results(section,cargo,place_id,local_payload_json,official_payload_json,public_payload_json,verification_status,updated_at,updated_by,version)
VALUES(?,?,?,?,?,?,?,?,?,1)`);
const updateRow = db.prepare(`UPDATE results SET place_id=?,local_payload_json=?,official_payload_json=?,public_payload_json=?,verification_status=?,updated_at=?,updated_by=?,version=version+1 WHERE section=? AND cargo=?`);
const deleteRow = db.prepare('DELETE FROM results WHERE section=? AND cargo=?');
const insertAudit = db.prepare('INSERT INTO audit(action,section,cargo,place_id,actor,before_json,after_json,created_at) VALUES(?,?,?,?,?,?,?,?)');
const auditRows = db.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT ?');

function safeJson(v, fallback={}) { try { return JSON.parse(v); } catch { return fallback; } }
function cleanPayload(input, actor, sourceKind) {
  const candidatos = Array.isArray(input.candidatos) ? input.candidatos.map(c => ({
    nome: String(c.nome || '').slice(0,120),
    numero: String(c.numero || '').slice(0,12),
    partido: String(c.partido || '').slice(0,30),
    votos: Math.max(0, Number(c.votos || 0) | 0)
  })) : [];
  const legendas = Array.isArray(input.legendas) ? input.legendas.map(l => ({
    numero: String(l.numero || '').slice(0,4),
    votos: Math.max(0, Number(l.votos || 0) | 0)
  })) : [];
  const rawBu = input.buMeta && typeof input.buMeta === 'object' ? input.buMeta : null;
  const buMeta = rawBu ? {
    zona: Math.max(0, Number(rawBu.zona || 0) | 0),
    secao: Math.max(0, Number(rawBu.secao || 0) | 0),
    secaoOriginal: Math.max(0, Number(rawBu.secaoOriginal || 0) | 0),
    municipioCodigo: String(rawBu.municipioCodigo || '').slice(0,12),
    urnaId: String(rawBu.urnaId || '').slice(0,30),
    pleito: String(rawBu.pleito || '').slice(0,20),
    turno: Math.max(0, Number(rawBu.turno || 0) | 0),
    versaoQr: String(rawBu.versaoQr || '').slice(0,20),
    hash: String(rawBu.hash || '').replace(/[^A-Fa-f0-9]/g,'').slice(0,128),
    assinaturaPresente: !!rawBu.assinaturaPresente,
    qrParts: Math.max(0, Number(rawBu.qrParts || 0) | 0),
    qrTotal: Math.max(0, Number(rawBu.qrTotal || 0) | 0),
    fingerprint: String(rawBu.fingerprint || '').replace(/[^A-Fa-f0-9]/g,'').slice(0,64),
    parsedAt: String(rawBu.parsedAt || '').slice(0,40),
    votosNominais: Math.max(0, Number(rawBu.votosNominais || 0) | 0),
    votosLegenda: Math.max(0, Number(rawBu.votosLegenda || 0) | 0)
  } : null;
  return {
    candidatos,
    legendas,
    buMeta,
    brancos: Math.max(0, Number(input.brancos || 0) | 0),
    nulos: Math.max(0, Number(input.nulos || 0) | 0),
    comparecimento: Math.max(0, Number(input.comparecimento || 0) | 0),
    fonte: String(input.fonte || (sourceKind === 'tse' ? 'TSE' : 'Boletim de Urna')).slice(0,100),
    atualizadoEm: new Date().toISOString(),
    enviadoPor: actor,
    sourceKind
  };
}
function comparable(p) {
  const x = typeof p === 'string' ? safeJson(p) : p;
  const cand = [...(x?.candidatos || [])].map(c => [String(c.numero), Number(c.votos||0)]).sort((a,b)=>a[0].localeCompare(b[0]));
  const leg = [...(x?.legendas || [])].map(l => [String(l.numero), Number(l.votos||0)]).sort((a,b)=>a[0].localeCompare(b[0]));
  return JSON.stringify({cand, leg, brancos:+x?.brancos||0, nulos:+x?.nulos||0, comparecimento:+x?.comparecimento||0});
}
function rowToPayload(row) {
  const p = safeJson(row.public_payload_json);
  p.verificationStatus = row.verification_status;
  p.version = row.version;
  p.placeId = row.place_id;
  p.updatedBy = row.updated_by;
  return p;
}
function snapshot() {
  const results = {};
  let latest = null;
  for (const row of listRows.all()) {
    results[`${row.section}:${row.cargo}`] = rowToPayload(row);
    if (!latest || row.updated_at > latest) latest = row.updated_at;
  }
  return {results, updatedAt: latest, total: Object.keys(results).length};
}

function parseOperators() {
  const map = new Map();
  const adminToken = process.env.ADMIN_TOKEN || (!isProd ? 'COLMEIA-ADMIN-DEMO' : '');
  if (adminToken) map.set(adminToken, {name:'Coordenação', role:'admin', sections:['*'], places:['*']});
  if (process.env.OPERATOR_TOKENS) {
    const raw = safeJson(process.env.OPERATOR_TOKENS, {});
    for (const [token, info] of Object.entries(raw)) if (token) {
      const sections = Array.isArray(info?.sections)
        ? info.sections.map(Number).filter(Number.isInteger)
        : [];
      const places = Array.isArray(info?.places) ? info.places.map(String) : [];
      map.set(token, {
        name: String(info?.name || 'Operador').slice(0,160),
        role: info?.role === 'admin' ? 'admin' : 'operator',
        sections,
        places
      });
    }
  }
  return map;
}
function auth(req) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7).trim() : '';
  const user = parseOperators().get(token);
  return user ? {...user, tokenHash: crypto.createHash('sha256').update(token).digest('hex').slice(0,10)} : null;
}
function canWrite(user, section) {
  return !!user && (user.role === 'admin' || user.sections.includes('*') || user.sections.includes(Number(section)));
}
function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});
  res.end(body);
}
function text(res, status, body, type='text/plain; charset=utf-8') { res.writeHead(status, {'content-type':type,'x-content-type-options':'nosniff'}); res.end(body); }
async function readBody(req) {
  let size=0, chunks=[];
  for await (const c of req) { size += c.length; if (size > 1024*1024) throw new Error('body_too_large'); chunks.push(c); }
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {};
}

const clients = new Set();
function broadcast(event='update', data={}) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) { try { res.write(payload); } catch { clients.delete(res); } }
}
setInterval(()=>{ for(const res of clients) { try {res.write(': ping\n\n')} catch {clients.delete(res)} } }, 25000).unref();

const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon'};
async function serveStatic(req,res,pathname) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  rel = decodeURIComponent(rel).replace(/\\/g,'/');
  const target = path.normalize(path.join(PUBLIC, rel));
  if (!target.startsWith(PUBLIC)) return text(res,403,'Forbidden');
  try {
    const st = await stat(target); if (!st.isFile()) throw new Error('not_file');
    const data = await readFile(target);
    res.writeHead(200, {'content-type':mime[path.extname(target)]||'application/octet-stream','cache-control': path.extname(target)==='.html'?'no-cache':'public, max-age=300','x-frame-options':'SAMEORIGIN','referrer-policy':'strict-origin-when-cross-origin','x-content-type-options':'nosniff'});
    res.end(data);
  } catch { text(res,404,'Not found'); }
}

const server = http.createServer(async (req,res) => {
  const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const p = u.pathname;
  try {
    if (p === '/api/health') return json(res,200,{ok:true,service:'Central Eleitoral Colméia 2026',version:'0.14.0',time:new Date().toISOString(),db:'sqlite',sse:true,persistentStorage:!!(process.env.DATA_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH),authConfigured:!!(process.env.ADMIN_TOKEN || process.env.OPERATOR_TOKENS)});
    if (p === '/api/whoami') {
      const user=auth(req); if(!user) return json(res,401,{ok:false,error:'unauthorized'});
      return json(res,200,{ok:true,user:{name:user.name,role:user.role,sections:user.sections,places:user.places}});
    }
    if (p === '/api/snapshot') return json(res,200,{ok:true,...snapshot()});
    if (p === '/api/stream') {
      res.writeHead(200, {'content-type':'text/event-stream','cache-control':'no-cache, no-transform','connection':'keep-alive','x-accel-buffering':'no'});
      res.write(`event: hello\ndata: ${JSON.stringify({time:new Date().toISOString()})}\n\n`);
      clients.add(res); req.on('close',()=>clients.delete(res)); return;
    }
    if (p === '/api/audit') {
      const user=auth(req); if(!user || user.role!=='admin') return json(res,403,{ok:false,error:'forbidden'});
      const limit=Math.max(1,Math.min(200,Number(u.searchParams.get('limit')||50)));
      return json(res,200,{ok:true,items:auditRows.all(limit).map(x=>({...x,before:x.before_json?safeJson(x.before_json):null,after:x.after_json?safeJson(x.after_json):null,before_json:undefined,after_json:undefined}))});
    }
    if (p === '/api/results' && req.method === 'POST') {
      const user=auth(req); if(!user) return json(res,401,{ok:false,error:'unauthorized'});
      const body=await readBody(req);
      const section=Number(body.section), cargo=String(body.cargo||''), placeId=sectionToPlace.get(section);
      if(!placeId || !allowedCargos.has(cargo)) return json(res,400,{ok:false,error:'invalid_section_or_cargo'});
      if(!canWrite(user,section)) return json(res,403,{ok:false,error:'operator_not_allowed_for_section',section,placeId});
      const sourceKind = body.sourceKind === 'tse' && user.role === 'admin' ? 'tse' : 'local';
      const payload=cleanPayload(body,user.name,sourceKind);
      const now=new Date().toISOString();
      const before=getRow.get(section,cargo) || null;
      let localJson=before?.local_payload_json||null, officialJson=before?.official_payload_json||null, publicJson, status;
      if(sourceKind==='tse') {
        officialJson=JSON.stringify(payload);
        if(localJson) status = comparable(localJson) === comparable(officialJson) ? 'verified' : 'divergent';
        else status='tse_official';
        publicJson=officialJson;
      } else {
        localJson=JSON.stringify(payload);
        if(officialJson) {
          status = comparable(localJson) === comparable(officialJson) ? 'verified' : 'divergent';
          publicJson=officialJson;
        } else { status='local_pending'; publicJson=localJson; }
      }
      if(before) updateRow.run(placeId,localJson,officialJson,publicJson,status,now,user.name,section,cargo);
      else insertRow.run(section,cargo,placeId,localJson,officialJson,publicJson,status,now,user.name);
      const after=getRow.get(section,cargo);
      insertAudit.run(before?'update':'create',section,cargo,placeId,`${user.name}#${user.tokenHash}`,before?JSON.stringify(before):null,JSON.stringify(after),now);
      broadcast('update',{section,cargo,placeId,verificationStatus:status,updatedAt:now});
      return json(res,200,{ok:true,result:rowToPayload(after),verificationStatus:status});
    }
    if (p === '/api/results' && req.method === 'DELETE') {
      const user=auth(req); if(!user || user.role!=='admin') return json(res,403,{ok:false,error:'admin_required'});
      const section=Number(u.searchParams.get('section')), cargo=String(u.searchParams.get('cargo')||'');
      const before=getRow.get(section,cargo); if(!before) return json(res,404,{ok:false,error:'not_found'});
      deleteRow.run(section,cargo);
      const now=new Date().toISOString(); insertAudit.run('delete',section,cargo,before.place_id,`${user.name}#${user.tokenHash}`,JSON.stringify(before),null,now);
      broadcast('delete',{section,cargo,updatedAt:now});
      return json(res,200,{ok:true});
    }
    if (p.startsWith('/api/')) return json(res,404,{ok:false,error:'not_found'});
    return serveStatic(req,res,p);
  } catch (err) {
    console.error(err);
    return json(res, err?.message==='body_too_large'?413:500, {ok:false,error: err?.message || 'server_error'});
  }
});
server.listen(PORT,'0.0.0.0',()=>{
  console.log(`Central Eleitoral Colméia 2026 em http://0.0.0.0:${PORT}`);
  console.log(`Banco SQLite: ${path.join(RUNTIME, 'central.sqlite')}`);
  if(!isProd && !process.env.ADMIN_TOKEN) console.log('DEV admin token: COLMEIA-ADMIN-DEMO');
  if(isProd && !process.env.ADMIN_TOKEN) console.warn('AVISO: ADMIN_TOKEN não configurado; não haverá chave administrativa.');
  if(isProd && !process.env.RAILWAY_VOLUME_MOUNT_PATH && !process.env.DATA_DIR) console.warn('AVISO: banco em armazenamento efêmero. Anexe um Volume antes do uso real.');
});
