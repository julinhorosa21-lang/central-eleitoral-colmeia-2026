# Central Eleitoral Colméia 2026 — V0.11

Esta versão transforma o painel estático em uma central com servidor e banco de dados compartilhado.

## O que já funciona

- Banco SQLite central com uma linha por seção + cargo.
- API pública de leitura (`/api/snapshot`).
- Atualização em tempo real entre navegadores por Server-Sent Events (`/api/stream`).
- Operadores autenticados por chave.
- Permissão por local de votação: uma chave pode ser limitada a uma escola/local.
- Coordenação com acesso administrativo.
- Auditoria: criação, correção e exclusão ficam registradas.
- Dados locais de BU e dados oficiais do TSE são armazenados separadamente.
- Status: `local_pending`, `tse_official`, `verified` ou `divergent`.
- Se o servidor cair, o navegador pode guardar um envio na fila local e tentar sincronizar ao voltar.
- A interface V0.10 foi preservada: mapa, locais, candidatos, fotos e apuração por cargo.

## Rodar no computador

Requer Node.js 22 ou superior.

```bash
npm start
```

Abra:

`http://localhost:8787`

Em modo de desenvolvimento, se nenhuma chave for configurada, a chave administrativa é:

`COLMEIA-ADMIN-DEMO`

**Nunca use essa chave em produção.**

## Criar chaves reais dos operadores

```bash
npm run tokens
```

O comando gera:

- uma chave da coordenação;
- uma chave diferente para cada um dos 10 locais de votação;
- um JSON para colocar em `OPERATOR_TOKENS`.

As chaves não devem ser colocadas dentro de `index.html`, GitHub público ou arquivos enviados ao público.

## Variáveis de ambiente

Veja `.env.example`.

- `PORT`
- `ADMIN_TOKEN`
- `OPERATOR_TOKENS`

## Banco

O arquivo é criado em:

`runtime/central.sqlite`

Em produção, essa pasta precisa estar em armazenamento persistente. Não use sistema de arquivos efêmero para o banco.

## Arquitetura

```
Público ────────┐
Operadores ─────┼──> servidor Node ──> SQLite
Coordenação ────┘         │
                          └── SSE -> atualização ao vivo

Futuro TSE/QR BU ─────────> mesma API -> conferência automática
```

## Próximas etapas

1. Publicar o servidor em hospedagem com disco persistente e HTTPS.
2. Gerar/distribuir as chaves dos 10 locais.
3. Implementar leitor do QR Code do Boletim de Urna.
4. Implementar importador EA16/EA18/EA20 do TSE.
5. Criar painel privado de auditoria e divergências.
6. Transformar em PWA instalável/offline.

## Observação

A Central é um projeto independente. Quando integrarmos os dados do TSE, o app deve diferenciar claramente resultados recebidos localmente por BU e resultados oficiais da Justiça Eleitoral.

## V0.12 — pronta para Railway

- Detecta automaticamente `RAILWAY_VOLUME_MOUNT_PATH` para persistir o SQLite.
- Servidor escuta em `0.0.0.0` e usa a variável `PORT` da hospedagem.
- `/api/health` informa se armazenamento persistente e autenticação estão configurados.
- Inclui `DEPLOY_RAILWAY.md`, `.dockerignore` e `npm run check`.


## V0.13 — leitura de QR do Boletim de Urna

- Leitura pela câmera do navegador em HTTPS.
- Captura automática de BUs com múltiplos QR Codes e remontagem por `QRBU:parte:total`.
- Interpretação estrutural dos cargos 1, 3, 5, 6 e 7 das eleições gerais.
- Preenchimento automático de candidatos, brancos, nulos e comparecimento.
- Votos de legenda preservados para cargos proporcionais.
- Botão para revisar um cargo ou salvar todos os cargos lidos.
- Fingerprint SHA-256 local do conteúdo remontado e metadados do BU gravados junto ao resultado.
- A V0.13 **não valida criptograficamente a assinatura do QR**; ela apenas registra a presença de HASH/ASSI. A validação por chaves públicas do TSE fica para etapa posterior.
