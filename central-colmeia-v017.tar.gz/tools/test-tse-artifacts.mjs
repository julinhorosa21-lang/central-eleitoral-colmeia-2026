import assert from 'node:assert/strict';
import { artifactUrl, classifyArtifact, normalizeEa18, sanitizeArtifactName } from '../tse-sync.mjs';

assert.equal(sanitizeArtifactName('p000123-to-m12345-z0016-s0049.bu'), 'p000123-to-m12345-z0016-s0049.bu');
assert.equal(sanitizeArtifactName('../secret.env'), null);
assert.equal(sanitizeArtifactName('a/b.bu'), null);
assert.equal(classifyArtifact('urna.bu'), 'BU');
assert.equal(classifyArtifact('urna.vscmr'), 'SIGNATURE');
assert.equal(classifyArtifact('urna.rdv'), 'RDV');

const aux = {
  st: 'Recebida',
  hashes: [{
    hash: 'ABCDEF0123456789',
    dr: '04/10/2026',
    hr: '17:01:02',
    st: 'Recebido',
    arq: [
      {nm:'p000123-to-m12345-z0016-s0049.bu',tp:'BU'},
      {nm:'p000123-to-m12345-z0016-s0049.vscmr',tp:'Assinatura'},
      {nm:'../nao-pode.env',tp:'Outro'}
    ]
  }]
};
const batches = normalizeEa18(aux);
assert.equal(batches.length, 1);
assert.equal(batches[0].files.length, 2);
assert.equal(batches[0].files[0].class, 'BU');
assert.equal(batches[0].files[1].class, 'SIGNATURE');
const url = artifactUrl({
  base:'https://resultados.tse.jus.br', env:'oficial', cycle:'ele2026', pleitoCode:'123',
  municipalityCode:'12345', section:49, batchHash:'ABCDEF0123456789', fileName:batches[0].files[0].name
});
assert.equal(url, 'https://resultados.tse.jus.br/oficial/ele2026/arquivo-urna/123/dados/to/12345/0016/0049/ABCDEF0123456789/p000123-to-m12345-z0016-s0049.bu');
assert.equal(artifactUrl({base:'https://x',env:'oficial',cycle:'ele2026',pleitoCode:'1',municipalityCode:'1',section:1,batchHash:'bad/../hash',fileName:'x.bu'}), null);

console.log('OK: parser EA18 e URL exata de artefatos');
console.log('OK: proteção contra path traversal');
console.log('OK: classificação BU/assinatura/RDV');
