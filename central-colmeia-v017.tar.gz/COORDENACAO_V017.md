# Painel da Coordenação — V0.17

Acesso: botão **Painel da Coordenação** e chave administrativa.

O painel mostra as 29 seções receptoras, os cinco cargos esperados, situação do EA18, preservação do BU oficial, divergências, última atualização e auditoria.

A V0.17 deliberadamente não decodifica o arquivo `.bu` binário usando uma especificação antiga. O TSE disponibilizou para 2024 a especificação ASN.1 e scripts de leitura; até que a especificação de 2026 seja publicada/confirmada, a Central preserva o artefato oficial e seu hash, sem declarar comparação voto a voto.
