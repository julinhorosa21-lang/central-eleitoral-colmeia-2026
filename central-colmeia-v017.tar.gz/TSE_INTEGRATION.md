# Integração TSE — V0.16

A V0.16 amplia o conector oficial da Central Eleitoral de Colméia para localizar e preservar os arquivos de urna publicados pelo TSE, mantendo separados os dados locais do QR e os artefatos oficiais.

## Fluxo implementado

1. Consulta `/<ambiente>/comum/config/ele-c.json` (EA11).
2. Procura o pleito do primeiro turno em `04/10/2026`.
3. Descobre ciclo, código do pleito e códigos das eleições sem fixá-los manualmente.
4. Monta a URL do EA16 usando o template publicado no próprio EA11.
5. No EA16, localiza TO -> Colméia -> 16ª Zona Eleitoral.
6. Acompanha as 29 seções receptoras da base local.
7. Só tenta EA18 quando o EA16 informa `da` e `ha`.
8. Lê do EA18 os hashes e os nomes exatos dos arquivos de urna; não adivinha nomes de arquivos.
9. Registra em SQLite os metadados de todos os artefatos listados no EA18.
10. Baixa automaticamente os arquivos classificados como BU e assinatura, com limite de tamanho e proteção contra path traversal.
11. Preserva os bytes no volume persistente e calcula SHA-256 e SHA-512 para trilha de integridade local.

Os artefatos são gravados em:

`<DATA_DIR>/tse/artifacts/<seção>/<hash>/<arquivo>`

Na Railway, `DATA_DIR` é substituído pelo volume detectado em `RAILWAY_VOLUME_MOUNT_PATH`, atualmente montado em `/data`.

## Regra de segurança da conferência

A V0.16 **não marca um resultado como `verified` apenas porque o arquivo BU oficial foi localizado ou baixado**.

Os estados `verified` e `divergent` continuam reservados à comparação do conteúdo de votos entre o dado local e um payload oficial decodificado. O arquivo `.bu` oficial é binário/ASN.1; a etapa de decodificação e comparação voto a voto será ativada somente depois de validada contra amostras 2026.

Também não se presume que o `HASH` lido no QR seja igual ao hash de pasta do EA18 ou ao SHA calculado do arquivo. Cada identificador fica registrado em seu contexto próprio.

## Endpoints

- `GET /api/tse/status` — estado público do conector, incluindo contagem de BUs oficiais listados/baixados.
- `GET /api/tse/section?section=49` — evidência oficial e artefatos conhecidos de uma seção, sem expor caminho local do servidor.
- `POST /api/tse/refresh` — atualização manual, restrita à coordenação.

## Configuração opcional

- `TSE_BASE_URL` (padrão: `https://resultados.tse.jus.br`)
- `TSE_AMBIENTE` (padrão: `oficial`)
- `TSE_POLL_SECONDS` (padrão: `60`, mínimo: `30`)
- `TSE_MAX_ARTIFACT_BYTES` (padrão: `26214400`, 25 MiB)

Enquanto o EA11 ainda não contiver o pleito de 2026, o conector permanece em `waiting_2026_config` e não constrói URLs especulativas para EA16/EA18 ou arquivos de urna.
