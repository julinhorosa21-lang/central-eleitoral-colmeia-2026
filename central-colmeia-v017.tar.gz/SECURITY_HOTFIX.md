# Hotfix de segurança V0.16.1

Objetivo: impedir reaproveitamento silencioso de credenciais de operador no navegador.

- Credenciais não são persistidas em localStorage/sessionStorage.
- Recarregar ou fechar a página encerra a sessão do operador.
- Sessão aberta expira após 15 minutos sem atividade.
- Painel de lançamento e leitor/colar QR exigem autenticação antes de abrir.
- Toda escrita continua protegida no backend por Authorization e escopo de seção.
- Uma seção não pode gravar em outra seção.
- Em modo offline, somente uma sessão já validada e ainda aberta pode enfileirar lançamentos; após recarga, novo login online é obrigatório.
