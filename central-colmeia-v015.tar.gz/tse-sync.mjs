const DEFAULT_BASE = 'https://resultados.tse.jus.br';
const DEFAULT_ENV = 'oficial';
const TARGET_DATE = '04/10/2026';
const TARGET_UF = 'to';
const TARGET_CITY = 'colmeia';
const TARGET_ZONE = '0016';

const pad = (v, n) => String(v ?? '').replace(/\D/g, '').padStart(n, '0');
const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const nowIso = () => new Date().toISOString();

export function createTseSync({db, locations, broadcast, baseUrl, ambiente, pollSeconds}) {
  const base = String(baseUrl || process.env.TSE_BASE_URL || DEFAULT_BASE).replace(/\/+$/, '');
  const env = String(ambiente || process.env.TSE_AMBIENTE || DEFAULT_ENV).replace(/^\/+|\/+$/g, '');
  const configuredPoll = Math.max(30, Number(pollSeconds || process.env.TSE_POLL_SECONDS || 60));
  const localSections = [...new Set(locations.locais.flatMap(l => l.secoes.map(Number)))].sort((a,b)=>a-b);
  const cache = new Map();
  let running = false;
  let stopped = false;
  let timer = null;

  db.exec(`
    CREATE TABLE IF NOT EXISTS tse_sections (
      section INTEGER PRIMARY KEY,
      principal_section INTEGER NOT NULL,
      aggregated_json TEXT NOT NULL,
      ea16_available INTEGER NOT NULL DEFAULT 0,
      aux_date TEXT,
      aux_time TEXT,
      tse_status TEXT,
      hash_count INTEGER NOT NULL DEFAULT 0,
      last_hash_status TEXT,
      updated_at TEXT NOT NULL
    );
  `);
  const upsert = db.prepare(`INSERT INTO tse_sections(section,principal_section,aggregated_json,ea16_available,aux_date,aux_time,tse_status,hash_count,last_hash_status,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(section) DO UPDATE SET
      principal_section=excluded.principal_section,
      aggregated_json=excluded.aggregated_json,
      ea16_available=excluded.ea16_available,
      aux_date=excluded.aux_date,
      aux_time=excluded.aux_time,
      tse_status=excluded.tse_status,
      hash_count=excluded.hash_count,
      last_hash_status=excluded.last_hash_status,
      updated_at=excluded.updated_at`);
  const listDb = db.prepare('SELECT * FROM tse_sections ORDER BY section');

  const state = {
    source: 'TSE · Divulgação de Resultados 2026',
    baseUrl: base,
    ambiente: env,
    phase: 'initializing',
    message: 'Preparando integração com a divulgação oficial do TSE.',
    lastAttempt: null,
    lastSuccess: null,
    lastError: null,
    cycle: null,
    pleitoCode: null,
    electionCodes: [],
    municipalityCode: null,
    municipalityName: 'Colméia',
    zone: TARGET_ZONE,
    sectionsExpected: localSections.length,
    ea16Url: null,
    summary: {known:0, auxiliaryReady:0, received:0, totalized:0},
  };

  function publicSections() {
    const out = {};
    for (const r of listDb.all()) {
      out[String(r.section)] = {
        section: r.section,
        principalSection: r.principal_section,
        aggregated: JSON.parse(r.aggregated_json || '[]'),
        tseFileAvailable: !!r.ea16_available,
        auxiliaryDate: r.aux_date || null,
        auxiliaryTime: r.aux_time || null,
        tseStatus: r.tse_status || null,
        hashCount: Number(r.hash_count || 0),
        lastHashStatus: r.last_hash_status || null,
        updatedAt: r.updated_at,
      };
    }
    return out;
  }

  function getStatus() {
    return {...state, sections: publicSections()};
  }

  async function fetchJson(url, {allow404=false}={}) {
    const prev = cache.get(url);
    const headers = {'accept':'application/json'};
    if (prev?.etag) headers['if-none-match'] = prev.etag;
    if (prev?.lastModified) headers['if-modified-since'] = prev.lastModified;
    let res;
    try {
      res = await fetch(url, {headers, signal: AbortSignal.timeout(12000)});
    } catch (e) {
      throw new Error(`tse_network:${e?.name || 'error'}`);
    }
    if (res.status === 304 && prev?.json) return prev.json;
    if (res.status === 404 && allow404) return null;
    if (!res.ok) throw new Error(`tse_http_${res.status}`);
    const json = await res.json();
    cache.set(url, {json, etag:res.headers.get('etag'), lastModified:res.headers.get('last-modified')});
    return json;
  }

  function find2026Pleito(cfg) {
    const pleitos = Array.isArray(cfg?.pl) ? cfg.pl : [];
    return pleitos.find(p => String(p.dt || '') === TARGET_DATE) || null;
  }

  function electionDescriptors(pleito) {
    return (Array.isArray(pleito?.e) ? pleito.e : []).map(e => ({
      code: String(e.cd || ''),
      turn: String(e.t || ''),
      name: String(e.nm || '').replace(/&[^;]+;/g, ' '),
      cargos: (Array.isArray(e.abr) ? e.abr : []).flatMap(a => Array.isArray(a.cp) ? a.cp.map(c => Number(c.cd)) : []),
    }));
  }

  function templateDir(cfg, tp, vars) {
    const item = (Array.isArray(cfg?.arq) ? cfg.arq : []).find(x => x.tp === tp);
    if (!item?.dir) return null;
    const replacements = {
      '<base>': base,
      '<ambiente>': env,
      '<ciclo>': vars.cycle,
      '<cd_eleicao>': vars.electionCode || '',
      '<cd_pleito>': vars.pleitoCode || '',
      '<uf>': vars.uf || TARGET_UF,
    };
    let dir = item.dir;
    for (const [token, value] of Object.entries(replacements)) dir = dir.split(token).join(String(value));
    return dir.replace(/\/+$/, '');
  }

  function ea18Url({cycle, pleitoCode, municipalityCode, section}) {
    const p6 = pad(pleitoCode, 6), m5 = pad(municipalityCode, 5), z4 = pad(TARGET_ZONE, 4), s4 = pad(section, 4);
    return `${base}/${env}/${cycle}/arquivo-urna/${pleitoCode}/dados/${TARGET_UF}/${m5}/${z4}/${s4}/p${p6}-${TARGET_UF}-m${m5}-z${z4}-s${s4}-aux.json`;
  }

  function persistSection(section, record, aux) {
    const aggregated = Array.isArray(record?.nsa) ? record.nsa.map(x=>Number(x)).filter(Number.isInteger) : [];
    const hashes = Array.isArray(aux?.hashes) ? aux.hashes : [];
    const latest = hashes[hashes.length - 1] || null;
    upsert.run(
      Number(section), Number(section), JSON.stringify(aggregated), record?.da && record?.ha ? 1 : 0,
      record?.da || null, record?.ha || null, aux?.st || null, hashes.length,
      latest?.st || null, nowIso()
    );
  }

  function updateSummary() {
    const rows = listDb.all();
    state.summary = {
      known: rows.filter(r=>localSections.includes(Number(r.section))).length,
      auxiliaryReady: rows.filter(r=>r.ea16_available).length,
      received: rows.filter(r=>Number(r.hash_count)>0).length,
      totalized: rows.filter(r=>norm(r.tse_status).includes('totalizada') || norm(r.last_hash_status).includes('totalizado')).length,
    };
  }

  async function refresh({manual=false}={}) {
    if (running) return getStatus();
    running = true;
    state.lastAttempt = nowIso();
    state.lastError = null;
    try {
      const cfgUrl = `${base}/${env}/comum/config/ele-c.json`;
      const cfg = await fetchJson(cfgUrl);
      const pleito = find2026Pleito(cfg);
      if (!pleito) {
        state.phase = 'waiting_2026_config';
        state.cycle = cfg?.c || null;
        state.pleitoCode = null;
        state.electionCodes = [];
        state.message = 'Conector pronto. O arquivo EA11 público ainda não contém o pleito de 4/10/2026.';
        updateSummary();
        return getStatus();
      }

      const cycle = String(cfg.c || 'ele2026');
      const pleitoCode = String(pleito.cd || '');
      const elections = electionDescriptors(pleito);
      state.cycle = cycle;
      state.pleitoCode = pleitoCode;
      state.electionCodes = elections;

      const csDir = templateDir(cfg, 'cs', {cycle, pleitoCode, uf:TARGET_UF});
      if (!csDir) throw new Error('tse_ea11_missing_cs_template');
      const ea16Url = `${csDir}/${TARGET_UF}-p${pad(pleitoCode,6)}-cs.json`;
      state.ea16Url = ea16Url;
      const ea16 = await fetchJson(ea16Url, {allow404:true});
      if (!ea16) {
        state.phase = 'waiting_ea16';
        state.message = 'Pleito 2026 identificado; aguardando o arquivo EA16 de seções do Tocantins.';
        updateSummary();
        return getStatus();
      }

      const abr = (ea16.abr || []).find(a => norm(a.cd) === TARGET_UF);
      const mu = (abr?.mu || []).find(m => norm(m.nm) === TARGET_CITY);
      if (!mu) throw new Error('tse_colmeia_not_found_in_ea16');
      state.municipalityCode = pad(mu.cd,5);
      const zone = (mu.zon || []).find(z => pad(z.cd,4) === TARGET_ZONE);
      if (!zone) throw new Error('tse_zone_0016_not_found');
      const bySection = new Map((zone.sec || []).map(s => [Number(s.ns), s]));

      let found = 0;
      for (const section of localSections) {
        const rec = bySection.get(section);
        if (!rec) continue;
        found++;
        let aux = null;
        if (rec.da && rec.ha) {
          const url = ea18Url({cycle, pleitoCode, municipalityCode:mu.cd, section});
          try { aux = await fetchJson(url, {allow404:true}); }
          catch (e) { console.warn('EA18 indisponível', section, e.message); }
        }
        persistSection(section, rec, aux);
      }

      updateSummary();
      state.phase = found === localSections.length ? 'ready' : 'partial_sections';
      state.lastSuccess = nowIso();
      state.message = found === localSections.length
        ? `EA16 carregado para Colméia/16ª ZE. ${state.summary.received}/${localSections.length} seções já têm arquivos de urna recebidos pelo TSE.`
        : `EA16 carregado, mas ${localSections.length-found} seção(ões) local(is) ainda não foram encontradas na configuração oficial.`;
      broadcast?.('tse_update', {phase:state.phase, summary:state.summary, updatedAt:state.lastSuccess});
      return getStatus();
    } catch (e) {
      state.phase = 'error';
      state.lastError = String(e?.message || e);
      state.message = 'Não foi possível atualizar a integração do TSE agora. A central local continua funcionando normalmente.';
      console.warn('[TSE sync]', e);
      return getStatus();
    } finally {
      running = false;
      if (!manual) schedule();
    }
  }

  function schedule() {
    if (stopped) return;
    clearTimeout(timer);
    const seconds = state.phase === 'waiting_2026_config' ? Math.max(300, configuredPoll) : configuredPoll;
    timer = setTimeout(() => refresh(), seconds * 1000);
    timer.unref?.();
  }

  function start() {
    setTimeout(()=>refresh(), 1200).unref?.();
  }
  function stop() { stopped = true; clearTimeout(timer); }

  return {getStatus, refresh, start, stop};
}
