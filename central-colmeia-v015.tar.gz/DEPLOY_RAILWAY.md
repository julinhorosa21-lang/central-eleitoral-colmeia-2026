# Publicar a Central Eleitoral Colméia 2026 na Railway

Esta pasta já está pronta para Node.js 22 + Dockerfile.

## Configuração recomendada

- Serviço web: esta pasta inteira
- Healthcheck: `/api/health`
- Porta: NÃO definir manualmente. A Railway fornece `PORT` automaticamente.
- Volume persistente: anexar ao serviço em `/data`
- O servidor detecta `RAILWAY_VOLUME_MOUNT_PATH` automaticamente e salva o SQLite nesse volume.

## Variáveis obrigatórias antes do uso real

`ADMIN_TOKEN` = chave longa e secreta da coordenação

`OPERATOR_TOKENS` = JSON com uma chave por seção receptora (29 chaves). Gere localmente com `npm run tokens`, ou peça à Central para gerar e guardar as chaves com segurança.

Exemplo estrutural (NÃO use esta chave):

`{"CHAVE_EXEMPLO":{"name":"Operador · Seção 1 · Serra das Cordilheiras","role":"operator","sections":[1],"places":["serra-cordilheiras"]}}`

## No painel da Railway

1. Criar um projeto e um serviço para esta aplicação.
2. Fazer o deploy da pasta/repositório.
3. Anexar um Volume ao serviço com mount path `/data`.
4. Em Variables, adicionar `ADMIN_TOKEN` e `OPERATOR_TOKENS`.
5. Em Settings > Healthcheck, usar `/api/health`.
6. Gerar um domínio público HTTPS.
7. Acessar `https://SEU-DOMINIO/api/health` e conferir:
   - `ok: true`
   - `persistentStorage: true`
   - `authConfigured: true`
8. Só depois distribuir o link público e as chaves dos operadores.

## Segurança

- Nunca colocar `ADMIN_TOKEN` ou `OPERATOR_TOKENS` no `public/index.html`.
- Nunca publicar `.env` em repositório público.
- A população NÃO precisa de chave para acompanhar a apuração.
- Somente operadores/coordenação recebem chaves de escrita.

## Backup

O banco fica no volume persistente, como `central.sqlite`. Ative backups do Volume no provedor antes da eleição.

## Teste antes da eleição

Faça pelo menos um ensaio com dois celulares:

1. Celular A abre o painel e registra uma seção com uma chave de operador.
2. Celular B abre o link público sem chave.
3. O resultado deve aparecer automaticamente no B.
4. Reinicie/reimplante o serviço e confirme que o resultado continua lá. Isso confirma que o Volume está funcionando.
