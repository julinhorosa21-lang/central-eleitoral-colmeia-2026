import crypto from 'node:crypto';
import { readFileSync } from 'node:fs';
const data=JSON.parse(readFileSync(new URL('../public/data/locais-colmeia.json',import.meta.url),'utf8'));
const token=()=>crypto.randomBytes(18).toString('base64url');
const operators={};
for(const p of data.locais){
  for(const sec of p.secoes){
    const agregadas=(p.agregadas?.[String(sec)]||[]);
    const label=agregadas.length?`${sec} (agregada: ${agregadas.join(', ')})`:String(sec);
    operators[token()]={name:`Operador · Seção ${label} · ${p.nome}`,role:'operator',sections:[Number(sec)],places:[p.id]};
  }
}
const admin=token();
console.log('ADMIN_TOKEN='+admin);
console.log('OPERATOR_TOKENS='+JSON.stringify(operators));
console.log(`\nChaves geradas: ${Object.keys(operators).length} operadores de seção + 1 coordenação.`);
console.log('Guarde esses valores em local seguro. Não coloque as chaves no código público.');
