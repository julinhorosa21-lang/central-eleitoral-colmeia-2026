(function(root){
  'use strict';
  const CARGO_MAP={1:'presidente',3:'governador',5:'senador',6:'depFederal',7:'depEstadual'};
  const CARGO_NAMES={1:'Presidente',3:'Governador',5:'Senador',6:'Deputado Federal',7:'Deputado Estadual'};
  const GLOBAL_ANYWHERE=new Set(['HASH','ASSI']);
  const NUMBER_FIELDS=new Set(['SECA','ZONA','MUNI','COMP','APTO','FALT','LOCA','TURN','PLEI','IDEL','IDUE','HBMA']);
  function splitToken(token){const p=String(token||'').indexOf(':');return p<0?[String(token||''),'']:[token.slice(0,p),token.slice(p+1)];}
  function fragmentInfo(raw){
    const text=String(raw||'').trim();
    const m=text.match(/^QRBU:(\d+):(\d+)(?:\s|$)/i);
    if(!m)return null;
    const index=Number(m[1]), total=Number(m[2]);
    if(!Number.isInteger(index)||!Number.isInteger(total)||index<1||total<1||index>total)return null;
    return {index,total,text};
  }
  function assemble(parts){
    const arr=Array.isArray(parts)?parts:Object.values(parts||{});
    const parsed=arr.map(fragmentInfo).filter(Boolean).sort((a,b)=>a.index-b.index);
    if(!parsed.length)throw new Error('qrbu_header_missing');
    const total=parsed[0].total;
    if(parsed.some(p=>p.total!==total))throw new Error('qrbu_total_mismatch');
    const uniq=new Map(parsed.map(p=>[p.index,p]));
    if(uniq.size!==total)throw new Error('qrbu_incomplete');
    const body=[];
    for(let i=1;i<=total;i++){
      const p=uniq.get(i); if(!p)throw new Error('qrbu_incomplete');
      body.push(p.text.replace(/^QRBU:\d+:\d+\s*/i,'').trim());
    }
    return `QRBU:1:${total} ${body.join(' ')}`.trim();
  }
  function asNumber(v){const n=Number(v);return Number.isFinite(n)?n:0;}
  function parse(raw){
    const text=String(raw||'').replace(/[\r\n\t]+/g,' ').replace(/\s+/g,' ').trim();
    if(!/^QRBU:\d+:\d+(?:\s|$)/i.test(text))throw new Error('not_qrbu');
    const tokens=text.split(' ');
    const header=fragmentInfo(text);
    const meta={qrTotal:header?.total||1};
    const cargos=[]; let current=null, currentParty=null;
    function finish(){
      if(!current)return;
      const byNum=new Map();
      for(const c of current.candidatos){const k=String(c.numero);byNum.set(k,{numero:k,votos:(byNum.get(k)?.votos||0)+asNumber(c.votos)});}
      current.candidatos=[...byNum.values()].sort((a,b)=>a.numero.localeCompare(b.numero,'pt-BR',{numeric:true}));
      const leg=new Map();
      for(const l of current.legendas){const k=String(l.numero);leg.set(k,{numero:k,votos:(leg.get(k)?.votos||0)+asNumber(l.votos)});}
      current.legendas=[...leg.values()].sort((a,b)=>a.numero.localeCompare(b.numero,'pt-BR',{numeric:true}));
      current.cargo=CARGO_MAP[current.codigo]||null;
      current.nome=CARGO_NAMES[current.codigo]||`Cargo ${current.codigo}`;
      cargos.push(current); current=null; currentParty=null;
    }
    for(let i=1;i<tokens.length;i++){
      const tok=tokens[i]; if(!tok)continue;
      const [keyRaw,valueRaw]=splitToken(tok); const key=keyRaw.toUpperCase(), value=valueRaw;
      if(key==='QRBU')continue;
      if(key==='CARG'){
        finish(); current={codigo:asNumber(value),cargo:null,nome:'',tipo:null,candidatos:[],legendas:[],brancos:0,nulos:0,total:0,nominais:0,votosLegenda:0,fields:{}}; continue;
      }
      if(GLOBAL_ANYWHERE.has(key)){meta[key]=value;continue;}
      if(!current){meta[key]=NUMBER_FIELDS.has(key)?asNumber(value):value;continue;}
      if(key==='PART'){currentParty=String(value);continue;}
      if(key==='LEGP'){
        const votos=asNumber(value); current.votosLegenda+=votos;
        if(currentParty)current.legendas.push({numero:currentParty,votos});
        continue;
      }
      if(key==='TIPO'){current.tipo=asNumber(value);continue;}
      if(key==='BRAN'){current.brancos=asNumber(value);continue;}
      if(key==='NULO'){current.nulos=asNumber(value);continue;}
      if(key==='TOTC'){current.total=asNumber(value);continue;}
      if(key==='NOMI'){current.nominais=asNumber(value);continue;}
      if(key==='LEGC'){current.votosLegenda=asNumber(value);continue;}
      if(/^\d+$/.test(key)){
        current.candidatos.push({numero:key,votos:asNumber(value)});continue;
      }
      current.fields[key]=value;
    }
    finish();
    return {raw:text,meta,cargos,recognizedCargos:cargos.filter(c=>c.cargo)};
  }
  root.BUParser={CARGO_MAP,CARGO_NAMES,fragmentInfo,assemble,parse};
})(typeof globalThis!=='undefined'?globalThis:this);
