# Integração TSE — V0.15

A V0.15 prepara a Central Eleitoral de Colméia para acompanhar a chegada dos arquivos oficiais de urna por seção sem misturar dados locais com dados oficiais.

## Fluxo implementado

1. Consulta `/<ambiente>/comum/config/ele-c.json` (EA11).
2. Procura o pleito do primeiro turno em `04/10/2026`.
3. Descobre automaticamente ciclo, código do pleito e códigos das eleições.
4. Monta a URL do EA16 usando o template publicado no próprio EA11.
5. No EA16, localiza TO → Colméia → 16ª Zona Eleitoral.
6. Acompanha as 29 seções receptoras da base local.
7. Só tenta EA18 quando o EA16 informa `da` e `ha`, indicando que o arquivo auxiliar foi gerado.
8. Armazena em SQLite apenas metadados de chegada/totalização por seção.

## O que esta versão não faz

- Não usa EA20 municipal para substituir resultados por seção.
- Não afirma que um BU local foi confirmado pelo TSE apenas porque o EA18 apareceu.
- Não interpreta ainda o arquivo binário oficial de BU apontado pelo EA18.

A comparação oficial seção a seção será feita em uma versão posterior, baixando o BU oficial indicado no EA18 e interpretando seu conteúdo.

## Endpoints

- `GET /api/tse/status` — status público e resumo por seção.
- `POST /api/tse/refresh` — atualização manual, restrita à coordenação.

## Configuração opcional

- `TSE_BASE_URL` (padrão: `https://resultados.tse.jus.br`)
- `TSE_AMBIENTE` (padrão: `oficial`)
- `TSE_POLL_SECONDS` (padrão: `60`, mínimo: `30`)

Enquanto o EA11 ainda não contiver o pleito de 2026, o conector permanece em `waiting_2026_config` e não constrói URLs especulativas para EA16/EA18.
